# HOVER: Metric-Aware Hypothesis Selection for Open-Ended Video Game Glitch Detection — CVPR 2027 sources

```
main.tex            main paper (CVPR 2027 author kit, review mode; body within 8 pages (pdfLaTeX), references follow on page 8)
supp.tex            supplementary material (separate PDF; compile main.tex first)
sec/                main-paper sections; sec/Supplimentary-figures-Backbones/ qualitative figures
figs/               data figures (PDF + PNG) and the TikZ overview figs/pipeline.tex (Fig. 2)
tables/             LaTeX table bodies, generated from data/ by the scripts below
data/               evaluation outputs every number is read from
  master_metrics_all.csv, all_mode_comparisons.csv, ...   main run (main Tab. 1)
  revision/revision_*.csv                                  main run (controls, ablations,
                                                           re-judging, probe, segmentation grid)
  revision_earlier_run/revision_*.csv                      second complete run (Supp. Tabs. S10, S17)
  timing/report_test_100.md, timing/all_backbones_timing.csv   inference time (100 clips)
scripts/            make_tables.py, make_time_tables.py, make_revision_tables.py,
                    make_figures.py, make_xref.py, make_qualitative.py
main.bib            references (new ones checked against arXiv / venue pages)
cvpr.sty, ieeenat_fullname.bst, preamble.tex           CVPR 2027 author kit (no paper ID)
xref/               frozen cross-document labels (fallback when main.aux / supp.aux is absent)
```

## Build (order matters: later scripts overwrite some files of earlier ones)

```
python scripts/make_tables.py            # main-run tables (rerun_tests, full_modes, counts, selector, ual*, numbers)
python scripts/make_time_tables.py       # time_main, time_full, time_contrasts, time_numbers, figs/time.pdf
python scripts/make_revision_tables.py   # Tab. 1, 3-6 and the controls/ablation/re-judging tables of Supp. S6; seg_grid.tex
python scripts/make_figures.py           # data figures
latexmk -pdf main.tex
latexmk -pdf supp.tex
latexmk -pdf -g main.tex                 # picks up the final supplement numbers
python scripts/make_xref.py              # refresh xref/ after any renumbering
```

Overleaf: upload the zip as a new project; `main.tex` is the main document. For the supplement set
`supp.tex` as main document. The frozen labels in `xref/` are used automatically.

## What changed in this revision

- **Title**: "HOVER: Metric-Aware Hypothesis Selection for Open-Ended Video Game Glitch Detection" (the
  stages that carry the result in the five-backbone ablation are hypothesis formation and the
  metric-aware emission rule; verification and segmentation do not change the score measurably).
- **Main Tab. 1** now reports the same-stack GliDe re-run with paired 95% game-cluster intervals and
  exact game-level p (Holm), #reports and the rating-weighted IoU_r; published GliDe numbers in grey.
- **New controls (main Tab. 3, Supp. Tabs. S12-S13)**: GliDe + whole-clip spans / without prompt-example
  reports / merged / first / longest report / HOVER emission rule (+ whole clip); vanilla forced to one
  whole-clip report; four fixed-sentence baselines. **Decomposition against the re-run (main Tab. 4)**.
  **Ablation on all five backbones (main Tab. 6, Supp. Tab. S14)**, post-hoc emission x span table
  (Supp. Tab. S15), re-judging (Supp. Tab. S16), probe on five backbones (main Tab. 5, Supp. Tab. S18),
  extended tau grid (Supp. Tabs. S4-S5), main run vs. a second complete run (Supp. Tab. S10).
- **All analyses paired with Tab. 1.** Controls, ablations (re-tuned end to end), post-hoc emission x
  span, re-judging (3 fresh judgings), probe, segmentation grid and decomposition were recomputed with
  `hover_revision.py` on the main-run outputs (data/revision). The earlier second complete run is kept
  only to report run-to-run variation (Supp. Tab. S10, up to 3.67 F1xIoU; data/revision_earlier_run).
  Notable changes vs. the earlier draft: the judge-selected development medoid is now "The car appears
  to be flying or hovering above the ground ..." and scores 30.97 (was 26.75). Its selection effect is
  now reported (medoid_candidates.py -> data/revision/revision_medoid_candidates.csv, Supp. Tab. S11): the 40 short-listed descriptions score 9.09-30.97 on test (median
  23.89), and a TF-IDF medoid chosen without the judge (new row of Tab. 3) scores 26.37 (HOVER
  significantly above it on Q-3B and I-8B, indistinguishable elsewhere). The judge-selected sentence
  is labelled an oracle: tied with HOVER on Qwen2.5-VL-3B and significantly above it on the other
  four. The fixed-sentence block is now Holm-corrected over five sentences. GliDe with
  HOVER's emission rule + whole clip is indistinguishable from HOVER on four backbones and significantly
  below it on InternVL2.5-8B; ablation ranges are now 4.81-10.39 (event resolution) and 5.18-11.16
  (utility selection); calibration/verification change F1xIoU by at most 0.92 (n.s.); re-judging SD of
  HOVER <= 0.37 and every significance decision of Tab. 1 is reproduced under all four judgings.
- **Timing on all five backbones** (data/timing/all_backbones_timing.csv); speed-up 5.0-20.8x.
- Fig. 1 is now the Skyrim clip (over-reporting and prompt-example echo); the Skate 3 clip moved to
  Supp. Fig. S4b with a corrected caption. Fig. 2 is a vector TikZ schematic (old raster figure removed).
  Fig. 3 (profiles) moved to Supp. Fig. S9. The UAL-Bench table moved to Supp. Tab. S22.
- Reviewer-flagged fixes: all cross-references typed (Tab./Fig./Sec./Eq./Prop.), symbols de-overloaded
  (stage names in sans serif, emitted set E, GT intervals in calligraphic T), selector-gate wording,
  half-up rounding everywhere (61.625 -> 61.63), Holm families stated, internal jargon removed from the
  supplement, MMSS bound 59, UAL "calls" column removed (counts were not comparable across backbones),
  new references (F-measure optimisation, SODA, dense captioning, VQAScore, PhysBench, Order from Chaos,
  VideoGameBunny, TempGlitch, geometry-clipping VLMs, vLLM, Fisher, Viterbi, GPTDroid, BLIP-2).

## Before submitting — items only the authors can confirm

1. Supp. Sec. S6 reports the 1.4-3.7-point difference between the two complete runs (different report
   sets and, for two backbones, different refine modes) without naming its cause; be ready to explain it.
2. Definitions of the controls in Supp. Sec. S6 (merge keeps the earliest description; "emission rule"
   = HOVER stages V and U applied to GliDe reports; per-game sentence; development medoid; the generic
   sentence) describe hover_revision.py, which produced every number in data/revision.
3. Supp. Tab. S20 lacks bootstrap intervals for the HOVER rows of InternVL2.5-4B/8B and UI-TARS-1.5-7B
   (only per-method summaries are in all_backbones_timing.csv); the H/G intervals of main Tab. 7 for these
   three backbones are typed in scripts/make_time_tables.py (HG_CI_EXTERNAL) from your earlier table.
4. How the twelve games were chosen is not stated; reviewers may ask.
5. arXiv-only references: VideoGlitchBench/GliDe, Qwen2.5-VL, InternVL2.5, UI-TARS, Llama 3, Order from
   Chaos, TempGlitch, geometry-clipping study.
