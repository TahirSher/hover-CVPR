# Report Once: A Simple Training-Free Baseline and an Audit of Open-Ended Video Game Glitch Detection — CVPR 2027 sources

```
main.tex            main paper (CVPR 2027 author kit, review mode; body within 8 pages (pdfLaTeX), references follow on page 8)
supp.tex            supplementary material (separate PDF; compile main.tex first)
sec/                main-paper sections; sec/Supplimentary-figures-Backbones/ qualitative figures
figs/               data figures (PDF + PNG) and the TikZ overview figs/pipeline.tex (Fig. 2)
tables/             LaTeX table bodies, generated from data/ by the scripts below
data/               evaluation outputs every number is read from
  master_metrics_all.csv, all_mode_comparisons.csv, ...   main run (main Tab. 1)
  revision/revision_*.csv                                  main run (controls, ablations,
                                                           re-judging, probe, segmentation grid)
  revision_earlier_run/revision_*.csv                      second complete run (Supp. Tabs. S10, S17)
  timing/report_test_100.md, timing/all_backbones_timing.csv   inference time (100 clips)
scripts/            make_tables.py, make_time_tables.py, make_revision_tables.py,
                    make_figures.py, make_xref.py, make_qualitative.py
main.bib            references (new ones checked against arXiv / venue pages)
cvpr.sty, ieeenat_fullname.bst, preamble.tex           CVPR 2027 author kit (no paper ID)
xref/               frozen cross-document labels (fallback when main.aux / supp.aux is absent)
```

## Build (order matters: later scripts overwrite some files of earlier ones)

```
python scripts/make_tables.py            # main-run tables (rerun_tests, full_modes, counts, selector, ual*, numbers)
python scripts/make_time_tables.py       # time_main, time_full, time_contrasts, time_numbers, figs/time.pdf
python scripts/make_revision_tables.py   # Tab. 1, 3-6 and the controls/ablation/re-judging tables of Supp. S6; seg_grid.tex
python scripts/make_v2_tables.py         # second revision: Tab. 1 (overwrites), robustness, new backbones, timing, Supp. second-revision tables
python scripts/make_figures.py           # data figures
latexmk -pdf main.tex
latexmk -pdf supp.tex
latexmk -pdf -g main.tex                 # picks up the final supplement numbers
python scripts/make_xref.py              # refresh xref/ after any renumbering
```

Overleaf: upload the zip as a new project; `main.tex` is the main document. For the supplement set
`supp.tex` as main document. The frozen labels in `xref/` are used automatically.

## Pre-submission changes (anticipated reviewer questions)

- **Proposition 1 holds under Hungarian matching**: part (i) is now stated for the marginal gain of a report under
  the evaluator's matching (exact, no independence assumption); new part (iii): on a clip with one ground-truth
  glitch a further report pays only if it beats the matched one by more than F/2 (Supp. Sec. S3).
- **Clips with several glitches, games, budget** (Supp. Sec. S9.9, Tab. S36; data/v2/v4_*.csv from v4_reviewer.py,
  cached outputs and judge ratings only): 13 test clips (117 of 5,238 benchmark clips, 2.2%) have more than one
  glitch, so one report per clip caps recall at 94.5% on test and 97.0% overall; the core beats the GliDe re-run on
  those 13 clips with 4 of 5 backbones; it beats the re-run in 57 of 60 (game, backbone) cells; per clip GliDe makes
  52-142 VLM calls with 87k-251k prompt tokens, the core 21-23 with 24k-33k (session-independent budget).
- **Correction**: the test split has 13 clips with several glitches (the text said 14).
- **Same-session timing** (Supp. Tab. S23; data/v2/v4_timing_paired_*.csv from paired_timing.sh and
  v4_timing_paired_stats.py): vanilla, GliDe, the core and HOVER timed back to back on one vLLM server per backbone,
  20 test clips covering all 12 games. The core needs 0.09-0.21 of GliDe's total time (4.8-11.3x less) and HOVER
  0.11-0.22 (4.5-9.5x less); faster than GliDe on 19-20 of 20 clips on every backbone. All methods ran faster than in
  main Tab. 7, GliDe most, so the cross-session ratios of Tab. 7 overstate the gap (Qwen2.5-VL-3B: 0.08 vs 0.15);
  the speed-ups stated in the main text are the same-session ones.
- **Per-game fixed sentence** is now labelled an oracle: it is the TF-IDF medoid of the ground-truth descriptions of
  the other test clips of the same game (leave-one-clip-out).
- Only the core is called training-free (HOVER's selector and segmentation thresholds are fitted on development
  labels); ablation results reconciled with the core; UAL-Bench summary moved to the Discussion, with no claim of a
  localisation benefit beyond VideoGlitchBench; limitations on screening, text-only human check and multi-glitch recall.

## What changed in the third revision (response to the re-review)

- **Blinded human check of both judges** (Supp. Sec. S9.12, data/v2/v3_human_*.csv): two annotators rated
  140 matched test pairs (35 each for HOVER, the core, the GliDe re-run and the TF-IDF fixed sentence)
  independently, from text, with the benchmark rubric. Both rate the core far above the fixed sentence
  (+1.6 of 5, p < 0.001 for each annotator), which neither judge separates; both judges agree with the
  humans about as well as the annotators agree with each other (kappa_w 0.36 / 0.46 vs 0.38); the main
  judge is lenient (81% of pairs correct vs 44-48% for either annotator), the 72B judge strict (26%).
- **Clean GliDe re-runs** where its SAM 3 tracker had run out of memory (Qwen2.5-VL-3B, InternVL2.5-8B,
  UI-TARS-1.5-7B; 0 memory failures; Supp. Tabs. S27-S28, new rows of main
  Tab. 2): GliDe improves only on InternVL2.5-8B (+3.83); HOVER's and the core's gains over the clean
  re-runs are significant on all five backbones under both judges (HOVER on Q-3B: p = 0.046, 72B 0.018).
- **Full benchmark**: core and vanilla on all 5,238 clips of 120 games (Supp. Sec. S9.8,
  data/v2/v3_full*.csv); core 24.74-32.20, 24.86-32.30 on the 96 games never used; core > vanilla on
  every backbone (p < 0.001).
- **Correction**: the development (445 clips) and test (383 clips) splits contain twelve games each and
  are disjoint (the earlier text said both contain the same twelve games); no test game is seen in tuning.
- Shuffled-description and abstention controls (Supp. Sec. S9.7),
  MacKinnon-Nielsen-Webb reference for the few-cluster jackknife, limitations rewritten accordingly.

## What changed in the second revision (response to the expert review)

- **Reframed** around what the evidence shows. New title. The core, stage H with the best-supported
  hypothesis and a whole-clip span ("H + top-1"), is now a named row of Tab. 1: +2.92 to +13.68 over the
  GliDe re-run, significant on all five backbones (Holm over backbones), 20.9-22.6 VLM calls per clip.
  V, S and U are presented as tested components; none changes F1xIoU by more than 0.74 points.
- **New analyses** (data/v2, all paired with the main run): rating x IoU matching (conclusions unchanged);
  clip-level detection on the 76 glitch-free clips (every method, GliDe included, is at chance);
  short-glitch subsets (localisation pays only with Qwen2.5-VL-7B, +2.47, p = 0.001); GliDe's SAM 3
  tracker outcomes and a Qwen2.5-VL-3B re-run without it; glitch-definition test (neutral / GliDe's
  categories); a second judge (Qwen2.5-72B-Instruct-AWQ); a further backbone (Qwen3-VL-8B; Qwen2.5-VL-32B-AWQ did not fit on
  our GPU slice next to the judge); re-timing of the scored configurations with per-clip logs.
- **Corrections**: all five GliDe re-runs used SAM 3 (the earlier text said Qwen2.5-VL-3B did not);
  published-GliDe gains removed from the claims; jackknife t(11) intervals in Tab. 1 and Holm over the
  five backbones; disclosure that the selector gate was lowered from 0.5 to 0.44 during the main run;
  disclosure and re-tuning of InternVL2.5-8B, whose development judge requests failed in 388 of 855
  cases; items 1-14 of the review's inconsistency list.
- Probe table moved to the supplement; UAL-Bench section shortened.

## What changed in the first revision

- **Title**: "HOVER: Metric-Aware Hypothesis Selection for Open-Ended Video Game Glitch Detection" (the
  stages that carry the result in the five-backbone ablation are hypothesis formation and the
  metric-aware emission rule; verification and segmentation do not change the score measurably).
- **Main Tab. 1** now reports the same-stack GliDe re-run with paired 95% game-cluster intervals and
  exact game-level p (Holm), #reports and the rating-weighted IoU_r; published GliDe numbers in grey.
- **New controls (main Tab. 3, Supp. Tabs. S12-S13)**: GliDe + whole-clip spans / without prompt-example
  reports / merged / first / longest report / HOVER emission rule (+ whole clip); vanilla forced to one
  whole-clip report; four fixed-sentence baselines. **Decomposition against the re-run (main Tab. 4)**.
  **Ablation on all five backbones (main Tab. 6, Supp. Tab. S14)**, post-hoc emission x span table
  (Supp. Tab. S15), re-judging (Supp. Tab. S16), probe on five backbones (main Tab. 5, Supp. Tab. S18),
  extended tau grid (Supp. Tabs. S4-S5), main run vs. a second complete run (Supp. Tab. S10).
- **All analyses paired with Tab. 1.** Controls, ablations (re-tuned end to end), post-hoc emission x
  span, re-judging (3 fresh judgings), probe, segmentation grid and decomposition were recomputed with
  `hover_revision.py` on the main-run outputs (data/revision). The earlier second complete run is kept
  only to report run-to-run variation (Supp. Tab. S10, up to 3.67 F1xIoU; data/revision_earlier_run).
  Notable changes vs. the earlier draft: the judge-selected development medoid is now "The car appears
  to be flying or hovering above the ground ..." and scores 30.97 (was 26.75). Its selection effect is
  now reported (medoid_candidates.py -> data/revision/revision_medoid_candidates.csv, Supp. Tab. S11): the 40 short-listed descriptions score 9.09-30.97 on test (median
  23.89), and a TF-IDF medoid chosen without the judge (new row of Tab. 3) scores 26.37 (HOVER
  significantly above it on Q-3B and I-8B, indistinguishable elsewhere). The judge-selected sentence
  is labelled an oracle: tied with HOVER on Qwen2.5-VL-3B and significantly above it on the other
  four. The fixed-sentence block is now Holm-corrected over five sentences. GliDe with
  HOVER's emission rule + whole clip is indistinguishable from HOVER on four backbones and significantly
  below it on InternVL2.5-8B; ablation ranges are now 4.81-10.39 (event resolution) and 5.18-11.16
  (utility selection); calibration/verification change F1xIoU by at most 0.92 (n.s.); re-judging SD of
  HOVER <= 0.37 and every significance decision of Tab. 1 is reproduced under all four judgings.
- **Timing on all five backbones** (data/timing/all_backbones_timing.csv); speed-up 5.0-20.8x.
- Fig. 1 is now the Skyrim clip (over-reporting and prompt-example echo); the Skate 3 clip moved to
  Supp. Fig. S4b with a corrected caption. Fig. 2 is a vector TikZ schematic (old raster figure removed).
  Fig. 3 (profiles) moved to Supp. Fig. S9. The UAL-Bench table moved to Supp. Tab. S24.
- Reviewer-flagged fixes: all cross-references typed (Tab./Fig./Sec./Eq./Prop.), symbols de-overloaded
  (stage names in sans serif, emitted set E, GT intervals in calligraphic T), selector-gate wording,
  half-up rounding everywhere (61.625 -> 61.63), Holm families stated, internal jargon removed from the
  supplement, MMSS bound 59, UAL "calls" column removed (counts were not comparable across backbones),
  new references (F-measure optimisation, SODA, dense captioning, VQAScore, PhysBench, Order from Chaos,
  VideoGameBunny, TempGlitch, geometry-clipping VLMs, vLLM, Fisher, Viterbi, GPTDroid, BLIP-2).

## Before submitting — items only the authors can confirm

1. How the 24 development and test games were chosen is not stated (no selection script was kept). Supp. Tab. S34
   shows they resemble the 96 other games (duration, glitch-free and multi-glitch shares, glitch coverage, genres),
   and the core scores the same on the 96 unused games (Supp. Sec. S9.8).
2. Definitions of the controls in Supp. Sec. S6 describe hover_revision.py, which produced every number in
   data/revision.
3. arXiv-only references (no venue version found on 2026-11-06): VideoGlitchBench/GliDe, Qwen2.5-VL, InternVL2.5,
   UI-TARS, Llama 3, Kadavath et al., TempGlitch, geometry-clipping study. "Order from Chaos" is cited as TMLR
   (arXiv comment "Accepted by TMLR").

Resolved in the pre-submission round: the cause of the difference between the two complete runs is now stated
(Supp. Sec. S6: same settings on the Qwen backbones, which agree within 0.06; the second run described only four
windows per clip on the other three); all timing intervals of Supp. Tabs. S-time are computed from the per-clip
logs with the report's own code (data/timing/v4_timing_ci.csv; it reproduces the report), no value is typed in.
