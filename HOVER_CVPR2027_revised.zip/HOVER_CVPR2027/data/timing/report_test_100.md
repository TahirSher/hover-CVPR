# Inference time per video -- split=test, n=100 (subset sha1 59a0277f93)

| backbone | method | n | mean s/video [95% CI] | median [IQR] | p90 | RTF [95% CI] | requests/video | prompt tok/video | model-time share |
|---|---|---|---|---|---|---|---|---|---|
| qwen2.5-vl-3b | crux | 100 | 39.0 [30.8, 47.1] | 27.8 [19.1, 45.1] | 69.3 | 2.14 [2.07, 2.21] | 47.4 | 51981 | 82% |
| qwen2.5-vl-3b | glide | 100 | 329.5 [244.0, 415.1] | 249.9 [161.0, 410.6] | 663.4 | 18.08 [16.21, 20.16] | 123.5 | 204298 | 98% |
| qwen2.5-vl-3b | vanilla | 100 | 11.8 [8.5, 15.0] | 8.2 [6.2, 12.3] | 23.5 | 0.65 [0.54, 0.77] | 1.1 | 5782 | 41% |
| qwen2.5-vl-7b | crux | 100 | 29.3 [23.8, 34.7] | 22.7 [16.7, 37.9] | 56.5 | 1.60 [1.54, 1.67] | 37.0 | 41777 | 74% |
| qwen2.5-vl-7b | glide | 100 | 146.1 [104.1, 188.0] | 115.7 [71.1, 185.6] | 297.0 | 8.01 [6.77, 9.48] | 52.4 | 87017 | 95% |
| qwen2.5-vl-7b | vanilla | 100 | 9.3 [7.7, 11.0] | 8.0 [5.9, 11.1] | 17.9 | 0.51 [0.48, 0.55] | 1.0 | 5363 | 23% |
| internvl2.5-4b | glide | 99 | 385.0 [280.3, 489.7] | 290.5 [184.6, 467.5] | 783.4 | 21.34 [18.35, 24.81] | 141.8 | 247617 | 98% |
| internvl2.5-4b | vanilla | 100 | 16.6 [13.7, 19.6] | 12.0 [9.0, 20.4] | 34.7 | 0.91 [0.80, 1.03] | 1.9 | 15662 | 69% |
| internvl2.5-8b | glide | 100 | 452.8 [359.9, 545.6] | 340.4 [238.9, 539.1] | 893.4 | 24.83 [22.42, 27.51] | 142.4 | 251094 | 99% |
| internvl2.5-8b | vanilla | 100 | 21.1 [16.9, 25.4] | 19.8 [9.4, 29.1] | 40.2 | 1.16 [1.02, 1.31] | 1.5 | 12343 | 67% |
| ui-tars-1.5-7b | glide | 100 | 295.4 [217.9, 373.0] | 240.5 [136.6, 358.2] | 626.9 | 16.20 [14.46, 18.16] | 119.8 | 192323 | 98% |
| ui-tars-1.5-7b | vanilla | 100 | 15.1 [9.1, 21.0] | 9.6 [5.2, 22.4] | 38.0 | 0.83 [0.58, 1.18] | 1.2 | 6539 | 54% |

| backbone | contrast | n | geo-mean time ratio [95% CI] | total time ratio [95% CI] | game sign-flip p (Holm) | Wilcoxon p (cluster-naive) |
|---|---|---|---|---|---|---|
| qwen2.5-vl-3b | crux vs glide | 100 | 0.12 [0.11, 0.13] | 0.12 [0.10, 0.13] | 0.0005 (reject; G=12) | 0.0000 |
| qwen2.5-vl-3b | crux vs vanilla | 100 | 3.44 [3.14, 3.76] | 3.31 [2.85, 3.85] | 0.0005 (reject; G=12) | 0.0000 |
| qwen2.5-vl-3b | glide vs vanilla | 100 | 28.58 [23.96, 34.07] | 27.99 [22.46, 34.89] | 0.0005 (reject; G=12) | 0.0000 |
| qwen2.5-vl-7b | crux vs glide | 100 | 0.24 [0.19, 0.30] | 0.20 [0.17, 0.24] | 0.0005 (reject; G=12) | 0.0000 |
| qwen2.5-vl-7b | crux vs vanilla | 100 | 3.11 [3.00, 3.21] | 3.14 [3.04, 3.24] | 0.0005 (reject; G=12) | 0.0000 |
| qwen2.5-vl-7b | glide vs vanilla | 100 | 12.85 [10.17, 16.24] | 15.66 [12.83, 19.11] | 0.0005 (reject; G=12) | 0.0000 |
| internvl2.5-4b | glide vs vanilla | 99 | 21.58 [17.75, 26.23] | 23.16 [19.60, 27.36] | 0.0005 (reject; G=12) | 0.0000 |
| internvl2.5-8b | glide vs vanilla | 100 | 21.87 [18.61, 25.70] | 21.45 [17.86, 25.77] | 0.0005 (reject; G=12) | 0.0000 |
| ui-tars-1.5-7b | glide vs vanilla | 100 | 21.75 [14.75, 32.08] | 19.63 [12.19, 31.59] | 0.0005 (reject; G=12) | 0.0000 |

Time = wall clock from the raw .mp4 to the final report (preprocessing + all model requests + post-processing), sequential requests, no cross-run cache. RTF = total processing time / total video duration. Ratios are row method / column method (< 1: the first method is faster). CIs: game-cluster bootstrap, t(G-1).
