"""Inference-time tables and figure, read from data/timing/report_test_100.md.

Usage:  python scripts/make_time_tables.py      (run from the paper root)

Writes tables/time_main.tex (main paper), tables/time_full.tex and
tables/time_contrasts.tex (supplement), tables/time_numbers.tex (macros)
and figs/time.pdf/.png.  Nothing is typed in by hand: every number is parsed from
the timing report.  "crux" is the internal run name of HOVER in the report.
Backbones / methods missing from the report are printed as "--".
"""
import os
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

for _f in ["/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyretermes-regular.otf",
           "/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyretermes-bold.otf"]:
    if os.path.exists(_f):
        font_manager.fontManager.addfont(_f)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPORT = os.path.join(ROOT, "data", "timing", "report_test_100.md")
# Per-method summaries for all five backbones (100 clips). Used for the HOVER rows that
# the report above lacks (InternVL2.5-4B/8B, UI-TARS-1.5-7B); it has no bootstrap intervals.
SUMMARY = os.path.join(ROOT, "data", "timing", "all_backbones_timing.csv")
# Intervals and contrasts for every backbone, recomputed from the per-clip logs of the same session with the
# report's own statistics code (v4_timing_ci.py; it reproduces every row of the report). Used for the HOVER rows
# and HOVER contrasts that the report lacks (InternVL2.5-4B/8B, UI-TARS-1.5-7B).
COMPUTED = os.path.join(ROOT, "data", "timing", "v4_timing_ci.csv")
TABLES = os.path.join(ROOT, "tables")
FIGS = os.path.join(ROOT, "figs")

BACKBONES = ["qwen2.5-vl-3b", "qwen2.5-vl-7b", "internvl2.5-4b", "internvl2.5-8b",
             "ui-tars-1.5-7b"]
NICE = {"qwen2.5-vl-3b": "Qwen2.5-VL-3B", "qwen2.5-vl-7b": "Qwen2.5-VL-7B",
        "internvl2.5-4b": "InternVL2.5-4B", "internvl2.5-8b": "InternVL2.5-8B",
        "ui-tars-1.5-7b": "UI-TARS-1.5-7B"}
METHODS = [("vanilla", "Vanilla"), ("glide", "\\glide (re-run)"), ("crux", "\\hover")]
NUM = r"(-?[\d.]+)"
CI = rf"{NUM} \[{NUM}, {NUM}\]"


def parse():
    per, con = {}, {}
    with open(REPORT) as f:
        for line in f:
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) == 10 and cells[2].isdigit():
                b, m = cells[0], cells[1]
                mean = re.fullmatch(CI, cells[3]).groups()
                med = re.fullmatch(CI, cells[4]).groups()
                rtf = re.fullmatch(CI, cells[6]).groups()
                per[(b, m)] = dict(n=int(cells[2]), mean=mean, med=med, p90=cells[5], rtf=rtf,
                                   req=cells[7], tok=int(cells[8]),
                                   share=int(cells[9].rstrip("%")))
            elif len(cells) == 7 and cells[2].isdigit():
                b, (m1, m2) = cells[0], cells[1].split(" vs ")
                geo = re.fullmatch(CI, cells[3]).groups()
                tot = re.fullmatch(CI, cells[4]).groups()
                p = re.match(rf"{NUM} \((\w+); G=(\d+)\)", cells[5]).groups()
                con[(b, m1, m2)] = dict(n=int(cells[2]), geo=geo, tot=tot, p=p[0],
                                        decision=p[1], G=int(p[2]), wil=cells[6])
    return per, con


def fmt_p(p):
    v = float(p)
    if v < 1e-3:
        return r"$4.9{\times}10^{-4}$" if abs(v - 2 ** -11) < 1e-4 else f"${v:.1e}$"
    return f"{v:.3f}"


def fmt_wil(p):
    return r"$<10^{-4}$" if float(p) < 1e-4 else f"{float(p):.4f}"


def write(name, text):
    with open(os.path.join(TABLES, name), "w") as f:
        f.write(text)


def add_summary(per):
    """Fill (backbone, 'crux') entries missing from the report from the CSV summary."""
    import csv
    if not os.path.exists(SUMMARY):
        return
    with open(SUMMARY) as f:
        for r in csv.DictReader(f):
            b, m = r["backbone"], {"hover": "crux"}.get(r["method"], r["method"])
            if (b, m) in per:
                continue
            per[(b, m)] = dict(n=int(r["n_videos"]), mean=(f"{float(r['mean_s']):.1f}", None, None),
                               med=(f"{float(r['median_s']):.1f}", f"{float(r['p25_s']):.1f}",
                                    f"{float(r['p75_s']):.1f}"),
                               p90=f"{float(r['p90_s']):.1f}",
                               rtf=(f"{float(r['rtf']):.2f}", None, None),
                               req=f"{float(r['mean_requests']):.1f}",
                               tok=int(round(float(r["mean_prompt_tokens"]))),
                               share=int(round(100 * float(r["model_time_share"]))),
                               from_summary=True)


def add_computed(per, con):
    """Fill missing intervals (HOVER rows) and contrasts from COMPUTED."""
    import csv
    if not os.path.exists(COMPUTED):
        return
    for r in csv.DictReader(open(COMPUTED)):
        b = r["backbone"]
        if r["kind"] == "method":
            k = (b, {"hover": "crux"}.get(r["method"], r["method"]))
            if k in per and per[k]["mean"][1] is None:
                per[k]["mean"] = ("%.1f" % float(r["mean_s"]), "%.1f" % float(r["mean_lo"]), "%.1f" % float(r["mean_hi"]))
                per[k]["rtf"] = ("%.2f" % float(r["rtf"]), "%.2f" % float(r["rtf_lo"]), "%.2f" % float(r["rtf_hi"]))
        else:
            m1, m2 = ({"hover": "crux"}.get(x, x) for x in r["method"].split("/"))
            if (b, m1, m2) not in con:
                f = lambda c: tuple("%.2f" % float(r[c + s]) for s in ("", "_ci_lo", "_ci_hi"))
                con[(b, m1, m2)] = dict(n=int(r["n_videos"]), geo=f("geo_mean_ratio"), tot=f("total_time_ratio"),
                                        p=r["permutation_game_p"], decision="reject", G=int(r["n_games"]),
                                        wil=r["wilcoxon_cluster_naive_p"])


def summary_means():
    import csv
    out = {}
    if os.path.exists(SUMMARY):
        with open(SUMMARY) as f:
            for r in csv.DictReader(f):
                out[(r["backbone"], {"hover": "crux"}.get(r["method"], r["method"]))] = float(r["mean_s"])
    return out


def ci(t, star="$^\\ast$"):
    return f"{t[0]} [{t[1]}, {t[2]}]" if t[1] is not None else f"{t[0]}{star}"


def main():
    per, con = parse()
    add_summary(per)
    add_computed(per, con)
    import csv
    from decimal import Decimal, ROUND_HALF_UP
    if os.path.exists(SUMMARY):
        with open(SUMMARY) as f:
            for r in csv.DictReader(f):
                k = (r["backbone"], {"hover": "crux"}.get(r["method"], r["method"]))
                if k in per:
                    per[k]["req"] = str(Decimal(r["mean_requests"]).quantize(Decimal("0.1"), ROUND_HALF_UP))

    # ---------------- main paper: one compact row per backbone --------------
    rows = []
    for b in BACKBONES:
        cells = [NICE[b] + ("$^\\ast$" if any(per.get((b, m), {}).get("n", 100) < 100
                                              for m, _ in METHODS) else "")]
        for m, _ in METHODS:
            r = per.get((b, m))
            cells.append(f"{r['mean'][0]} & {r['rtf'][0]}" if r else "-- & --")
        c = con.get((b, "crux", "glide"))
        if c:
            cells.append(f"{c['tot'][0]} [{c['tot'][1]}, {c['tot'][2]}]")
        else:
            cells.append("--")
        sm = summary_means()
        if (b, "glide") in sm and (b, "vanilla") in sm:   # ratio of unrounded means
            cells.append(f"{sm[(b, 'glide')] / sm[(b, 'vanilla')]:.1f}")
        else:
            c = con.get((b, "glide", "vanilla"))
            cells.append(f"{float(c['tot'][0]):.1f}" if c else "--")
        rows.append(" & ".join(cells) + r" \\")
    write("time_main.tex", "\n".join(rows) + "\n")

    # ---------------- supplement: full per-method table ----------------------
    rows = []
    for b in BACKBONES:
        present = [(m, lab) for m, lab in METHODS if (b, m) in per]
        for k, (m, lab) in enumerate(present):
            r = per[(b, m)]
            head = (f"\\multirow{{{len(present)}}}{{*}}{{{NICE[b]}}}" if k == 0 else "")
            rows.append(
                f"{head} & {lab} & {r['n']} & {ci(r['mean'])} & "
                f"{r['med'][0]} [{r['med'][1]}, {r['med'][2]}] & {r['p90']} & "
                f"{ci(r['rtf'])} & {r['req']} & "
                f"{r['tok'] / 1000:.1f}k & {r['share']}\\% \\\\")
        rows.append("\\midrule")
    write("time_full.tex", "\n".join(rows[:-1]) + "\n")

    order = [("crux", "glide"), ("crux", "vanilla"), ("glide", "vanilla")]
    lab = {"crux": "HOVER", "glide": "GliDe", "vanilla": "Vanilla"}
    rows = []
    for b in BACKBONES:
        present = [o for o in order if (b,) + o in con]
        for k, (m1, m2) in enumerate(present):
            c = con[(b, m1, m2)]
            head = (f"\\multirow{{{len(present)}}}{{*}}{{{NICE[b]}}}" if k == 0 else "")
            rows.append(
                f"{head} & {lab[m1]} / {lab[m2]} & {c['n']} & "
                f"{c['geo'][0]} [{c['geo'][1]}, {c['geo'][2]}] & "
                f"{c['tot'][0]} [{c['tot'][1]}, {c['tot'][2]}] & {fmt_p(c['p'])} & "
                f"{fmt_wil(c['wil'])} \\\\")
        rows.append("\\midrule")
    write("time_contrasts.tex", "\n".join(rows[:-1]) + "\n")

    # ---------------- macros used in the text --------------------------------
    timed = [b for b in BACKBONES if (b, "crux") in per]
    sm = summary_means()
    sp = [(sm[(b, "glide")] / sm[(b, "crux")]) if (b, "crux") in sm else
          float(per[(b, "glide")]["mean"][0]) / float(per[(b, "crux")]["mean"][0]) for b in timed]
    gv = [float(con[(b, "glide", "vanilla")]["tot"][0]) for b in BACKBONES
          if (b, "glide", "vanilla") in con]
    gl = [float(per[(b, "glide")]["mean"][0]) for b in BACKBONES if (b, "glide") in per]
    write("time_numbers.tex", "\n".join([
        f"\\newcommand{{\\timeSpeedMin}}{{{min(sp):.1f}}}",
        f"\\newcommand{{\\timeSpeedMax}}{{{max(sp):.1f}}}",
        f"\\newcommand{{\\timeGVmin}}{{{min(gv):.0f}}}",
        f"\\newcommand{{\\timeGVmax}}{{{max(gv):.0f}}}",
        f"\\newcommand{{\\timeGlideMin}}{{{min(gl):.0f}}}",
        f"\\newcommand{{\\timeGlideMax}}{{{max(gl):.0f}}}",
        f"\\newcommand{{\\timeNclips}}{{{max(r['n'] for r in per.values())}}}",
    ]) + "\n")

    # ---------------- figure ---------------------------------------------------
    BLUE, ORANGE, GRAY, LGRAY, INK, MUTED = ("#2a78d6", "#eb6834", "#8a8a85", "#d4d3cf",
                                             "#222220", "#5f5e5a")
    plt.rcParams.update({
        "font.family": "serif", "font.serif": ["TeX Gyre Termes", "Times New Roman", "Times",
                                                "DejaVu Serif"],
        "font.size": 7.5, "axes.labelsize": 7.5, "xtick.labelsize": 7, "ytick.labelsize": 7,
        "legend.fontsize": 6.8, "axes.edgecolor": MUTED, "axes.linewidth": 0.6,
        "xtick.color": MUTED, "ytick.color": MUTED, "axes.labelcolor": INK, "text.color": INK,
        "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42,
        "savefig.bbox": "tight", "savefig.pad_inches": 0.02})
    short = {"qwen2.5-vl-3b": "Q-3B", "qwen2.5-vl-7b": "Q-7B", "internvl2.5-4b": "I-4B",
             "internvl2.5-8b": "I-8B", "ui-tars-1.5-7b": "UT-7B"}
    fig, ax = plt.subplots(figsize=(3.25, 1.75))
    x = np.arange(len(BACKBONES))
    w = 0.26
    for k, (m, name, col) in enumerate([("vanilla", "Vanilla", GRAY),
                                        ("glide", "GliDe (re-run)", ORANGE),
                                        ("crux", "HOVER", BLUE)]):
        xs, ys, lo, hi = [], [], [], []
        for i, b in enumerate(BACKBONES):
            r = per.get((b, m))
            if r:
                v = float(r["mean"][0])
                l = float(r["mean"][1]) if r["mean"][1] is not None else v
                h = float(r["mean"][2]) if r["mean"][2] is not None else v
                xs.append(x[i] + (k - 1) * w); ys.append(v); lo.append(v - l); hi.append(h - v)
        ax.bar(xs, ys, width=w * 0.92, color=col, label=name, linewidth=0)
        ax.errorbar(xs, ys, yerr=[lo, hi], fmt="none", ecolor=INK, elinewidth=0.6, capsize=1.5)
    for i, b in enumerate(BACKBONES):
        if (b, "crux") not in per:
            ax.text(x[i] + w, 4.5, "n/t", ha="center", va="bottom", fontsize=5.5, color=MUTED)
    ax.set_yscale("log")
    ax.set_ylim(3, 1000)
    ax.set_xticks(x)
    ax.set_xticklabels([short[b] for b in BACKBONES])
    ax.set_ylabel("seconds / clip (log)")
    ax.grid(axis="y", color=LGRAY, lw=0.3, which="major")
    ax.legend(frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.2))
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(FIGS, f"time.{ext}"), dpi=300)
    print("timing tables and figure written")


if __name__ == "__main__":
    main()
