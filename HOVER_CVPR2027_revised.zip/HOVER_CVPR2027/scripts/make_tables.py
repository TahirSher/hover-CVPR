"""Generate every results table of the paper (LaTeX fragments in ../tables)
directly from the evaluation outputs in ../data. Run from the paper root:

    python scripts/make_tables.py

Published numbers (UAL-Bench: Abdullah et al., WACV 2025, Tables 2 and 3;
GliDe: Zheng et al., VideoGlitchBench, Table 3) are the only values typed in by
hand; they are marked PUBLISHED below.
"""
import csv
import json
import math
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
TAB = os.path.join(ROOT, "tables")
os.makedirs(TAB, exist_ok=True)

BACKBONES = ["qwen2.5-vl-3b", "qwen2.5-vl-7b", "internvl2.5-4b", "internvl2.5-8b",
             "ui-tars-1.5-7b"]
NICE = {"qwen2.5-vl-3b": "Qwen2.5-VL-3B", "qwen2.5-vl-7b": "Qwen2.5-VL-7B",
        "internvl2.5-4b": "InternVL2.5-4B", "internvl2.5-8b": "InternVL2.5-8B",
        "ui-tars-1.5-7b": "UI-TARS-1.5-7B"}


def read_csv(name, enc="utf-8"):
    with open(os.path.join(DATA, name), encoding=enc) as f:
        return list(csv.DictReader(f))


MASTER = read_csv("master_metrics_all.csv")
CMP = read_csv("all_mode_comparisons.csv")
SELQ = {r["backbone"]: r for r in read_csv("selector_quality.csv")
        if r["calibration_mode"] == r["selected_refine_mode"]}


# PUBLISHED: GliDe results reported by Zheng et al. (VideoGlitchBench, Table 3):
# P, R, F1, mean IoU of matched pairs, F1xIoU (all in % except mIoU).  These are the
# GliDe numbers of main Tab. 1.  They were obtained on the authors' clip selection with
# their judge and come without per-clip outputs, so no paired test against them exists;
# paired tests use our same-stack re-run ("glide_official" in the data files).
GLIDE_PUB = {
    "qwen2.5-vl-3b": (32.36, 39.38, 35.52, 0.48, 17.29),
    "qwen2.5-vl-7b": (34.55, 45.09, 39.12, 0.53, 19.46),
    "internvl2.5-4b": (29.15, 36.87, 32.56, 0.52, 15.27),
    "internvl2.5-8b": (32.64, 40.97, 36.33, 0.50, 17.04),
    "ui-tars-1.5-7b": (34.31, 49.28, 40.45, 0.51, 17.02),
}
SHORT = {"qwen2.5-vl-3b": "Q-3B", "qwen2.5-vl-7b": "Q-7B", "internvl2.5-4b": "I-4B",
         "internvl2.5-8b": "I-8B", "ui-tars-1.5-7b": "UT-7B"}


def pub(b):
    P, R, F1, miou, fi = GLIDE_PUB[b]
    return {"precision": P, "recall": R, "f1": F1, "mean_iou": miou, "f1_iou": fi,
            "calls_per_video": float("nan")}


def r2(v):
    """Value as displayed with two decimals (differences are taken of displayed values)."""
    return round(v + 1e-12, 2)


def metric(b, mode, method):
    for r in MASTER:
        if r["backbone"] == b and r["refine_mode"] == mode and r["method"] == method:
            return {k: (float(v) if v not in ("",) else float("nan")) for k, v in r.items()
                    if k not in ("backbone", "refine_mode", "method")}
    raise KeyError((b, mode, method))


def comp(b, mode, other):
    for r in CMP:
        if r["backbone"] == b and r["refine_mode"] == mode and r["comparison"].endswith(other):
            return r
    raise KeyError((b, mode, other))


def sel(b):
    return SELQ[b]["selected_refine_mode"]


def fp(p):
    p = float(p)
    if p < 0.001:
        return "$<$0.001"
    return f"{p:.3f}"


def write(name, body):
    import re
    body = re.sub(r"(?<=[\s\[(&])-(?=\d)", "$-$", body)   # typographic minus, as in the other tables
    with open(os.path.join(TAB, name + ".tex"), "w") as f:
        f.write(body)


# ---------------------------------------------------------------------------
# Table: main results (calibration-selected refine mode per backbone)
# ---------------------------------------------------------------------------
def t_main():
    L = []
    for i, b in enumerate(BACKBONES):
        m = sel(b)
        rows = [("Vanilla", metric(b, m, "vanilla")), ("GliDe~\\cite{zheng2026open}", pub(b)),
                ("\\textbf{HOVER} (" + m + ")", metric(b, m, f"HOVER_{m}"))]
        # best per column, compared at the displayed precision (mIoU: two decimals,
        # the precision of the published numbers)
        keys = {"precision": 2, "recall": 2, "f1": 2, "mean_iou": 2, "f1_iou": 2}
        best = {k: max(round(r[1][k], d) for r in rows) for k, d in keys.items()}
        for j, (name, r) in enumerate(rows):
            def bf(k, fmt):
                s = fmt.format(r[k])
                return f"\\textbf{{{s}}}" if round(r[k], keys[k]) == best[k] else s
            calls = "--" if math.isnan(r["calls_per_video"]) else f"{r['calls_per_video']:.1f}"
            iou_fmt = "{:.2f}" if j == 1 else "{:.3f}"
            cells = [f"\\multirow{{3}}{{*}}{{{NICE[b]}}}" if j == 0 else "", name,
                     bf("precision", "{:.2f}"), bf("recall", "{:.2f}"), bf("f1", "{:.2f}"),
                     bf("mean_iou", iou_fmt), bf("f1_iou", "{:.2f}"), calls]
            cells.append(f"{r2(r['f1_iou']) - GLIDE_PUB[b][4]:+.2f}" if j == 2 else "")
            L.append(" & ".join(cells) + " \\\\")
        if i < len(BACKBONES) - 1:
            L.append("\\midrule")
    write("main_results", "\n".join(L) + "\n")


def t_rerun():
    """Same-stack paired comparison with our re-run of the released GliDe code."""
    L = []
    for i, b in enumerate(BACKBONES):
        g = metric(b, "window", "glide_official")
        first = True
        for mode in ["window", "frame", "whole"]:
            r = metric(b, mode, f"HOVER_{mode}")
            c = comp(b, mode, f"HOVER_{mode}")
            lo = -float(c["ci_hi_glide_minus_HOVER"])
            hi = -float(c["ci_lo_glide_minus_HOVER"])
            mark = "$\\star$" if mode == sel(b) else ""
            L.append(" & ".join([f"\\multirow{{4}}{{*}}{{{NICE[b]}}}" if first else "",
                                 f"\\multirow{{4}}{{*}}{{{GLIDE_PUB[b][4]:.2f}}}" if first else "",
                                 f"\\multirow{{4}}{{*}}{{{g['f1_iou']:.2f}}}" if first else "",
                                 f"HOVER ({mode}){mark}", f"{r['f1_iou']:.2f}",
                                 f"{r2(r['f1_iou']) - GLIDE_PUB[b][4]:+.2f}",
                                 f"{float(c['delta_HOVER_minus_glide']):+.2f} [{lo:+.2f}, {hi:+.2f}]",
                                 fp(c["permutation_p"]),
                                 "yes" if c["holm_reject"].strip().lower() == "true" else "no"]) + " \\\\")
            first = False
        v = metric(b, "window", "vanilla")
        c = comp(b, "window", "vanilla")
        L.append(" & ".join(["", "", "", "Vanilla", f"{v['f1_iou']:.2f}", "",
                             f"{-float(c['delta_glide_minus_HOVER']):+.2f} "
                             f"[{-float(c['ci_hi_glide_minus_HOVER']):+.2f}, {-float(c['ci_lo_glide_minus_HOVER']):+.2f}]",
                             fp(c["permutation_p"]),
                             "yes" if c["holm_reject"].strip().lower() == "true" else "no"]) + " \\\\")
        if i < len(BACKBONES) - 1:
            L.append("\\midrule")
    write("rerun_tests", "\n".join(L) + "\n")

# ---------------------------------------------------------------------------
# Table: grounding control and exact decomposition F1xIoU = F1 * IoU_r
# ---------------------------------------------------------------------------
def t_decomp():
    L, S = [], []
    for b in BACKBONES:
        m = sel(b)
        g = pub(b)
        h = metric(b, m, f"HOVER_{m}")
        w = metric(b, "whole", "HOVER_whole")
        iou_g, iou_h, iou_w = g["f1_iou"] / g["f1"], h["f1_iou"] / h["f1"], w["f1_iou"] / w["f1"]
        dloc = h["f1_iou"] - w["f1_iou"]
        share = math.log(h["f1"] / g["f1"]) / math.log(h["f1_iou"] / g["f1_iou"])
        cells = [m, f"{g['f1']:.2f}", f"{h['f1']:.2f}",
                 f"{iou_g:.3f}", f"{iou_h:.3f}", f"{iou_w:.3f}",
                 f"{g['f1_iou']:.2f}", f"{h['f1_iou']:.2f}", f"{w['f1_iou']:.2f}", f"{dloc:+.2f}",
                 f"{100 * share:.0f}\\%"]
        L.append(" & ".join([NICE[b]] + cells) + " \\\\")
        S.append(" & ".join([SHORT[b]] + cells) + " \\\\")
    write("decomposition", "\n".join(L) + "\n")
    write("decomposition_short", "\n".join(S) + "\n")

# ---------------------------------------------------------------------------
# Table: ablation (Qwen2.5-VL-3B; the only backbone whose ablation runs were judged)
# ---------------------------------------------------------------------------
def t_ablation():
    with open(os.path.join(DATA, "ablation_qwen2.5-vl-3b.csv"), encoding="latin-1") as f:
        lines = f.read().splitlines()
    start = [i for i, l in enumerate(lines) if l.startswith("Method,")][0]
    rows = {}
    for l in lines[start + 1:]:
        p = l.split(",")
        if len(p) > 6 and p[0]:
            rows[p[0]] = p
    lab = [("crux", "HOVER (full)", "--"),
           ("crux_no_ctx_calib", "\\quad w/o contextual calibration (V)", "V"),
           ("crux_no_hypothesis_scoring", "\\quad w/o hypothesis verification (V)", "V"),
           ("crux_no_segmentation", "\\quad w/o exact segmentation (S)", "S"),
           ("crux_no_subframe", "\\quad w/o sub-frame refinement (S)", "S"),
           ("crux_no_event_resolution", "\\quad w/o event resolution (H)", "H"),
           ("crux_no_utility_selection", "\\quad w/o utility selection (U)", "U"),
           ("glide_official", "GliDe~\\cite{zheng2026open} (re-run)", "--"),
           ("vanilla", "Vanilla", "--")]
    full = float(rows["crux"][5])
    L = []
    for k, name, _ in lab:
        p = rows[k]
        P, R, F1, miou, fi = (float(p[i]) for i in range(1, 6))
        calls = p[6] if p[6] and p[6][0].isdigit() else "--"
        d = "" if k in ("crux", "glide_official", "vanilla") else f"{fi - full:+.2f}"
        L.append(f"{name} & {P:.2f} & {R:.2f} & {F1:.2f} & {fi:.2f} & {d} & {calls} \\\\")
        if k in ("crux", "crux_no_utility_selection"):
            L.append("\\midrule")
    write("ablation", "\n".join(L) + "\n")


# ---------------------------------------------------------------------------
# Table: probe (dev subset, 72 videos / 709 windows / 12 games)
# ---------------------------------------------------------------------------
def t_probe():
    L = []
    names = {"lo_abs": "generic detector, calibrated", "lo_raw": "generic detector, raw",
             "hyp_top1": "hypothesis profile, top-1", "hyp_max": "hypothesis profile, max"}
    base = None
    for b in ["qwen2.5-vl-3b", "qwen2.5-vl-7b"]:
        d = json.load(open(os.path.join(DATA, "probe", f"probe_{b}.json")))
        base = d["base"]
        first = True
        for k in ["lo_raw", "lo_abs", "hyp_top1", "hyp_max"]:
            v = d["signals"][k]
            w, p, va = v["within_video_auc"], v["pooled_auc"], v["variance"]
            L.append(" & ".join([f"\\multirow{{4}}{{*}}{{{NICE[b]}}}" if first else "", names[k],
                                 f"{w['auc']:.3f} [{w['lo']:.3f}, {w['hi']:.3f}]",
                                 f"{p['auc']:.3f} [{p['lo']:.3f}, {p['hi']:.3f}]",
                                 f"{va['icc']:.2f}"]) + " \\\\")
            first = False
        h = d["hyp_vs_generic"]
        lo, hi = h["game_bootstrap_ci"]
        L.append(f" & \\multicolumn{{4}}{{l}}{{\\footnotesize per-video AUC, profile $-$ detector: "
                 f"{h['mean_delta_per_video_auc']:+.3f} [{lo:+.3f}, {hi:+.3f}], Wilcoxon $p={h['wilcoxon_p']:.3f}$ "
                 f"({h['n_videos']} videos)}} \\\\")
        if b == "qwen2.5-vl-3b":
            L.append("\\midrule")
    write("probe", "\n".join(L) + "\n")
    write("probe_base", f"% base-rate statistics of the probe subset\n"
          f"\\newcommand{{\\probeBaseRate}}{{{base['base_rate']:.3f}}}\n"
          f"\\newcommand{{\\probeWholeIoU}}{{{base['whole_video_span_iou_mean']:.3f}}}\n"
          f"\\newcommand{{\\probeOverHalf}}{{{100 * base['videos_over_half_positive']:.0f}}}\n"
          f"\\newcommand{{\\probeNWin}}{{{base['n_windows']}}}\n")


# ---------------------------------------------------------------------------
# Table: selector diagnostics (dev, out-of-fold)
# ---------------------------------------------------------------------------
def t_selector():
    L = []
    for b in BACKBONES:
        r = SELQ[b]
        L.append(" & ".join([NICE[b], f"{int(r['n_correct'])}/{int(r['n_hypotheses'])}",
                             f"{float(r['selector_oof_auc']):.3f} [{float(r['selector_oof_lo']):.3f}, {float(r['selector_oof_hi']):.3f}]",
                             f"{float(r['decision_threshold']):.3f}", f"{float(r['lipton_ratio']):.2f}",
                             f"{100 * float(r['f1_iou_emit_all']):.2f}",
                             f"{100 * float(r['f1_iou_emit_top1']):.2f}",
                             f"{100 * float(r['f1_iou_selected']):.2f}"]) + " \\\\")
    write("selector", "\n".join(L) + "\n")


# ---------------------------------------------------------------------------
# UAL-Bench
# ---------------------------------------------------------------------------
# PUBLISHED: Abdullah et al., WACV 2025, Table 2 (R@1 IoU 0.3/0.5/0.7, mIoU, mTD)
# and Table 3 (onset accuracy within 1 s / 0.25 s).
# Tuple order: name, mIoU, R@0.3, R@0.5, R@0.7, mTD, onset 1 s, onset 0.25 s.
PUB = {
    "uag_oops": [("BLIP2-LLaMA3$^\\ddagger$", 0.15, 19.07, 7.17, 2.45, 5.85, 39.33, 10.32),
                 ("VideoLLaMA-LLaMA3$^\\ddagger$", 0.15, 19.38, 7.93, 2.08, 5.72, 38.07, 9.19)],
    "uag_funqa": [("BLIP2-LLaMA3$^\\ddagger$", 0.12, 18.60, 9.30, 5.23, 5.43, 38.37, 13.95),
                  ("VideoLLaMA-LLaMA3$^\\ddagger$", 0.09, 12.21, 4.65, 2.33, 4.93, 41.28, 10.47)],
    "uag_ssbd": [("BLIP2-LLaMA3$^\\ddagger$", 0.03, 1.92, 1.92, 1.92, 68.05, 4.81, 0.00),
                 ("VideoLLaMA-LLaMA3$^\\ddagger$", 0.03, 2.88, 0.96, 0.00, 70.38, 8.65, 2.88)],
}


def load_ual():
    out = {}
    for fn in sorted(os.listdir(os.path.join(DATA, "ual"))):
        d = json.load(open(os.path.join(DATA, "ual", fn)))
        for sub, v in d["subsets"].items():
            for b, o in v["official"].items():
                out[(sub, b)] = (o, v["whole_video_reference"], v["n_items"],
                                 v["diagnostics_not_official"][b])
    return out


def t_ual():
    U = load_ual()
    subs = [("uag_oops", "UAG-OOPS"), ("uag_funqa", "UAG-FunQA"), ("uag_ssbd", "UAG-SSBD")]
    bbs = ["qwen2.5-vl-7b", "internvl2.5-8b", "ui-tars-1.5-7b"]
    L = []
    for si, (s, name) in enumerate(subs):
        w = U[(s, bbs[0])][1]
        K = ["miou", "r1_iou_0.3", "r1_iou_0.5", "r1_iou_0.7", "mtd", "onset_acc_1s", "onset_acc_0.25s"]
        # (name, decimals of mIoU, values...): published mIoU has two decimals, ours three
        rows = [(r[0], 2) + tuple(r[1:]) for r in PUB[s]]
        rows.append(("Whole-video span", 3) + tuple(w[k] for k in K))
        hv = [("HOVER-L, " + NICE[b], 3) + tuple(U[(s, b)][0][k] for k in K) for b in bbs]
        allr = rows + hv
        disp = lambda r, k: round(r[k + 2], r[1] if k == 0 else 2)
        best = [(min if k == 4 else max)(disp(r, k) for r in allr) for k in range(7)]
        for j, r in enumerate(allr):
            cells = [f"\\multirow{{{len(allr)}}}{{*}}{{\\rotatebox{{90}}{{\\scriptsize {name}}}}}" if j == 0 else "",
                     r[0]]
            for k in range(7):
                v = f"{r[k + 2]:.{r[1] if k == 0 else 2}f}"
                if disp(r, k) == best[k]:
                    v = f"\\textbf{{{v}}}"
                cells.append(v)
            L.append(" & ".join(cells) + " \\\\")
            if j == len(rows) - 1:
                L.append("\\cmidrule(l){2-9}")
        if si < len(subs) - 1:
            L.append("\\midrule")
    write("ual", "\n".join(L) + "\n")

    # supplementary: complete official metric set
    S = []
    for si, (s, name) in enumerate(subs):
        w = U[(s, bbs[0])][1]
        rows = [("Whole-video span", w, None)] + [(NICE[b], U[(s, b)][0], U[(s, b)][3]) for b in bbs]
        for j, (lab, o, dg) in enumerate(rows):
            calls = f"{dg['calls_per_item']:.1f}" if dg else "--"
            S.append(" & ".join([name if j == 0 else "", lab] +
                                [f"{o[k]:.2f}" for k in ["r1_iou_0.3", "r1_iou_0.5", "r1_iou_0.7"]] +
                                [f"{o['miou']:.3f}"] +
                                [f"{o[k]:.2f}" for k in ["r1_td_1", "r1_td_3", "r1_td_5", "r1_td_7"]] +
                                [f"{o['mtd']:.2f}", f"{o['onset_acc_1s']:.2f}", f"{o['onset_acc_0.25s']:.2f}"])
                     + " \\\\")  # calls per item omitted (counting not comparable across backbones)
        if si < len(subs) - 1:
            S.append("\\midrule")
    write("ual_full", "\n".join(S) + "\n")

    # CIs (video-cluster bootstrap) for the supplement
    C = []
    for s, name in subs:
        for b in bbs:
            ci = U[(s, b)][3]["ci95"]
            C.append(" & ".join([name, NICE[b],
                                 f"[{ci['miou'][0]:.3f}, {ci['miou'][1]:.3f}]",
                                 f"[{ci['r1_iou_0.5'][0]:.2f}, {ci['r1_iou_0.5'][1]:.2f}]",
                                 f"[{ci['mtd'][0]:.2f}, {ci['mtd'][1]:.2f}]"]) + " \\\\")
    write("ual_ci", "\n".join(C) + "\n")


# ---------------------------------------------------------------------------
# Supplementary: complete per-mode table and all comparisons
# ---------------------------------------------------------------------------
def hu(x, nd=2):
    """Round half up on the decimal representation (61.625 -> 61.63)."""
    from decimal import Decimal, ROUND_HALF_UP
    return str(Decimal(repr(float(x))).quantize(Decimal(1).scaleb(-nd), rounding=ROUND_HALF_UP))


def t_full():
    L = []
    for i, b in enumerate(BACKBONES):
        ms = sel(b)
        h_sel = metric(b, ms, f"HOVER_{ms}")
        v = metric(b, "window", "vanilla")
        L.append(" & ".join([NICE[b], "Vanilla", hu(v['precision']), hu(v['recall']),
                             hu(v['f1']), f"{v['mean_iou']:.3f}", hu(v['f1_iou']),
                             f"{v['calls_per_video']:.1f}",
                             f"{r2(v['f1_iou']) - GLIDE_PUB[b][4]:+.2f}"]) + " \\\\")   # same definition as the HOVER rows
        g = pub(b)
        L.append(" & ".join(["", "GliDe~\\cite{zheng2026open}", f"{g['precision']:.2f}",
                             f"{g['recall']:.2f}", f"{g['f1']:.2f}", f"{g['mean_iou']:.2f}",
                             f"{g['f1_iou']:.2f}", "--", ""]) + " \\\\")
        for mode in ["window", "frame", "whole"]:
            r = metric(b, mode, f"HOVER_{mode}")
            mark = "$\\star$" if mode == ms else ""
            L.append(" & ".join(["", f"HOVER ({mode}){mark}",
                                 hu(r['precision']), hu(r['recall']), hu(r['f1']),
                                 f"{r['mean_iou']:.3f}", hu(r['f1_iou']),
                                 f"{r['calls_per_video']:.1f}",
                                 f"{r2(r['f1_iou']) - GLIDE_PUB[b][4]:+.2f}"]) + " \\\\")
        if i < len(BACKBONES) - 1:
            L.append("\\midrule")
    write("full_modes", "\n".join(L) + "\n")

def t_counts():
    """Prediction counts and matched pairs (evaluated runs)."""
    L = []
    for b in BACKBONES:
        m = sel(b)
        g = metric(b, m, "glide_official")
        h = metric(b, m, f"HOVER_{m}")
        v = metric(b, m, "vanilla")
        L.append(" & ".join([NICE[b], f"{int(h['num_videos'])}", f"{int(h['num_gt_bugs'])}",
                             f"{int(v['num_pred_bugs'])} / {int(v['num_matched'])}",
                             f"{int(g['num_pred_bugs'])} / {int(g['num_matched'])}",
                             f"{int(h['num_pred_bugs'])} / {int(h['num_matched'])}",
                             f"{g['mean_score']:.2f}", f"{h['mean_score']:.2f}"]) + " \\\\")
    write("counts", "\n".join(L) + "\n")


def t_seg_grid():
    d = json.load(open(os.path.join(DATA, "probe", "calibration_qwen2.5-vl-7b.json")))
    tab = d["segmentation"]["table"]
    taus = sorted({float(k.split("|")[0]) for k in tab})
    lams = sorted({float(k.split("|")[1]) for k in tab})
    best = max(tab.values())
    L = []
    for t in taus:
        cells = [f"{t:g}"]
        for l in lams:
            key = f"{t:g}|{l:g}"
            v = tab.get(key)
            s = "--" if v is None else f"{v:.3f}"
            if v is not None and abs(v - best) < 1e-12:
                s = f"\\textbf{{{s}}}"
            cells.append(s)
        L.append(" & ".join(cells) + " \\\\")
    head = " & ".join(["$\\tau$ $\\backslash$ $\\lambda$"] + [("$\\infty$" if l > 1e8 else f"{l:g}") for l in lams])
    write("seg_grid", "\\begin{tabular}{l" + "c" * len(lams) + "}\n\\toprule\n" + head +
          " \\\\\n\\midrule\n" + "\n".join(L) + "\n\\bottomrule\n\\end{tabular}\n")


def t_numbers():
    """Macros for numbers quoted in the running text."""
    M = []
    pubd, rr = [], []
    for b in BACKBONES:
        m = sel(b)
        pubd.append(r2(metric(b, m, f"HOVER_{m}")["f1_iou"]) - GLIDE_PUB[b][4])
        rr.append(float(comp(b, m, f"HOVER_{m}")["delta_HOVER_minus_glide"]))
    # gains over the published GliDe numbers (main Tab. 1)
    M.append(f"\\newcommand{{\\minGain}}{{{min(pubd):.1f}}}")
    M.append(f"\\newcommand{{\\maxGain}}{{{max(pubd):.1f}}}")
    M.append(f"\\newcommand{{\\meanGain}}{{{sum(pubd) / len(pubd):.1f}}}")
    # gains over our same-stack re-run of GliDe (paired tests, supplement)
    M.append(f"\\newcommand{{\\minGainRR}}{{{min(rr):.1f}}}")
    M.append(f"\\newcommand{{\\maxGainRR}}{{{max(rr):.1f}}}")
    dl = []
    for b in BACKBONES:
        m = sel(b)
        dl.append(metric(b, m, f"HOVER_{m}")["f1_iou"] - metric(b, "whole", "HOVER_whole")["f1_iou"])
    M.append(f"\\newcommand{{\\maxLoc}}{{{max(dl):.2f}}}")
    M.append(f"\\newcommand{{\\minLoc}}{{{min(dl):.2f}}}")
    write("numbers", "\n".join(M) + "\n")

if __name__ == "__main__":
    t_main()
    t_rerun()
    t_decomp()
    t_ablation()
    t_probe()
    t_selector()
    t_ual()
    t_full()
    t_counts()
    t_seg_grid()
    t_numbers()
    print("tables written to", TAB)
