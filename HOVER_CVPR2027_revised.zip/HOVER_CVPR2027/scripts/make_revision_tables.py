"""Generate the tables added in the revision (main Tabs. 1, 3, 4, 5, 6 and
Supp. Tabs. S-controls, S-ablation, S-posthoc, S-rejudge, S-runs, S-seg, S-probe,
S-decomp, S-time) from the evaluation outputs in ../data. Run from the paper root:

    python scripts/make_revision_tables.py

Inputs
  data/master_metrics_all.csv, data/all_mode_comparisons.csv   main run (Tab. 1)
  data/revision/revision_*.csv                                  controls, ablations, re-judging,
                                                               probe, segmentation grid, repairs,
                                                               all paired with the main run
  data/revision_earlier_run/revision_*.csv                      an earlier complete run, used only
                                                               for the run-to-run comparison (S-runs)
  data/timing/all_backbones_timing.csv                          inference time, 100 clips
Typed-in values (marked PUBLISHED): GliDe's published results (Zheng et al., Tab. 3).
Every number printed by this script is read from those files; nothing is rounded twice.
"""
import csv
import math
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
REV = os.path.join(DATA, "revision")
TAB = os.path.join(ROOT, "tables")
os.makedirs(TAB, exist_ok=True)

BACKBONES = ["qwen2.5-vl-3b", "qwen2.5-vl-7b", "internvl2.5-4b", "internvl2.5-8b",
             "ui-tars-1.5-7b"]
NICE = {"qwen2.5-vl-3b": "Qwen2.5-VL-3B", "qwen2.5-vl-7b": "Qwen2.5-VL-7B",
        "internvl2.5-4b": "InternVL2.5-4B", "internvl2.5-8b": "InternVL2.5-8B",
        "ui-tars-1.5-7b": "UI-TARS-1.5-7B"}
SHORT = {"qwen2.5-vl-3b": "Q-3B", "qwen2.5-vl-7b": "Q-7B", "internvl2.5-4b": "I-4B",
         "internvl2.5-8b": "I-8B", "ui-tars-1.5-7b": "UT-7B"}
# Refine mode selected on the development split in the MAIN run (Tab. 1).
MAIN_MODE = {"qwen2.5-vl-3b": "whole", "qwen2.5-vl-7b": "window", "internvl2.5-4b": "window",
             "internvl2.5-8b": "frame", "ui-tars-1.5-7b": "window"}
# PUBLISHED: GliDe (Zheng et al., VideoGlitchBench, Table 3): P, R, F1, F1xIoU in %.
GLIDE_PUB = {"qwen2.5-vl-3b": (32.36, 39.38, 35.52, 17.29),
             "qwen2.5-vl-7b": (34.55, 45.09, 39.12, 19.46),
             "internvl2.5-4b": (29.15, 36.87, 32.56, 15.27),
             "internvl2.5-8b": (32.64, 40.97, 36.33, 17.04),
             "ui-tars-1.5-7b": (34.31, 49.28, 40.45, 17.02)}


def rd(path):
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def fnum(x):
    return float(x) if x not in ("", None) else float("nan")


def write(name, body):
    with open(os.path.join(TAB, name + ".tex"), "w") as f:
        f.write(body.rstrip("\n") + "\n")
    print("wrote tables/%s.tex" % name)


def rhu(x, nd=2):
    """Round half up (away from zero) on the decimal representation of x, so that
    e.g. 61.625 prints as 61.63 (Python's %-formatting would print 61.62)."""
    from decimal import Decimal, ROUND_HALF_UP
    q = Decimal(1).scaleb(-nd)
    return Decimal(repr(float(x))).quantize(q, rounding=ROUND_HALF_UP)


def f2(x):
    return str(rhu(x, 2))


def pct(x):          # fraction -> percent, 2 decimals
    return str(rhu(100.0 * x, 2))


def sgn(x, nd=2):
    v = rhu(x, nd)
    if v == 0:
        v = abs(v)          # never print "+-0.00"
    s = ("+" if v >= 0 else "") + str(v)
    return s.replace("-", "$-$") if v < 0 else s


def pc0(x):
    """share as integer percent; never prints -0%"""
    v = round(100 * x)
    return ("%d\\%%" % v).replace("-", "$-$") if v != 0 else "0\\%"


def pfmt(p):
    if p != p:
        return ""
    if p < 0.001:
        return "$<$0.001"
    return "%.3f" % p


# --------------------------------------------------------------------------- main run
MASTER = rd(os.path.join(DATA, "master_metrics_all.csv"))
CMP = rd(os.path.join(DATA, "all_mode_comparisons.csv"))


def mrow(b, method, mode=None):
    mode = mode or MAIN_MODE[b]
    for r in MASTER:
        if r["backbone"] == b and r["refine_mode"] == mode and r["method"] == method:
            return {k: fnum(v) for k, v in r.items() if k not in ("backbone", "refine_mode", "method")}
    raise KeyError((b, method, mode))


def mcmp(b, other, mode=None):
    mode = mode or MAIN_MODE[b]
    for r in CMP:
        if r["backbone"] == b and r["refine_mode"] == mode and r["comparison"].endswith(other):
            return r
    raise KeyError((b, other, mode))


# -------------------------------------------- revision analyses (paired with the main run)
CTRL = rd(os.path.join(REV, "revision_controls.csv"))
ABL = rd(os.path.join(REV, "revision_ablation.csv"))
POST = rd(os.path.join(REV, "revision_posthoc.csv"))
PROBE = rd(os.path.join(REV, "revision_probe.csv"))
REJ = rd(os.path.join(REV, "revision_rejudge.csv"))
SEG = rd(os.path.join(REV, "revision_seg_grid.csv"))
REP = rd(os.path.join(REV, "revision_repairs.csv"))
DEC = rd(os.path.join(REV, "revision_decompose.csv"))
TIME = rd(os.path.join(DATA, "timing", "all_backbones_timing.csv"))
# earlier complete run (run-to-run comparison only)
EREV = os.path.join(DATA, "revision_earlier_run")
E_CTRL = rd(os.path.join(EREV, "revision_controls.csv"))
E_POST = rd(os.path.join(EREV, "revision_posthoc.csv"))
E_REJ = rd(os.path.join(EREV, "revision_rejudge.csv"))


def rrow(rows, b, tag, variant):
    for r in rows:
        if r["backbone"] == b and r["tag"] == tag and r["variant"] == variant:
            return {k: (fnum(v) if k not in ("backbone", "tag", "variant", "holm_reject", "reference")
                        else v) for k, v in r.items()}
    raise KeyError((b, tag, variant))


# Ablation tag: "E5_ablate_main" (hover_revision.py, paired with the main run) if present,
# otherwise the earlier run's tag of revision_results.zip.
ABL_TAG = "E5_ablate_main" if any(r["tag"] == "E5_ablate_main" for r in ABL) else "E5_ablate_pinned"


def holm(r):
    return str(r.get("holm_reject", "")).strip().lower() == "true"


# =========================================================================== Tab. 1
def t_main():
    out = []
    for i, b in enumerate(BACKBONES):
        v, g, h = mrow(b, "vanilla"), mrow(b, "glide_official"), mrow(b, "HOVER_" + MAIN_MODE[b])
        cv, ch = mcmp(b, "vanilla"), mcmp(b, "HOVER_" + MAIN_MODE[b])
        P, R, F1, FI = GLIDE_PUB[b]
        best = max(v["f1_iou"], g["f1_iou"], h["f1_iou"], FI)

        def line(first, name, n, row, d=None, lo=None, hi=None, p=None, rej=None, grey=False):
            iour = row["f1_iou"] / row["f1"] if row["f1"] > 0 else float("nan")
            cells = ["%d" % n if n is not None else "--", f2(row["precision"]), f2(row["recall"]),
                     f2(row["f1"]), "%.3f" % iour,
                     ("\\textbf{%s}" % f2(row["f1_iou"])) if abs(row["f1_iou"] - best) < 1e-9 else f2(row["f1_iou"])]
            if d is None:
                cells += ["", ""]
            else:
                cells += ["%s [%s, %s]" % (sgn(d), sgn(lo), sgn(hi)),
                          pfmt(p) + ("$^\\dagger$" if rej else "")]
            if grey:
                cells = ["\\color{gray}" + c if c else c for c in cells]
                name = "\\color{gray}" + name
            lead = ("\\multirow{4}{*}{%s}" % NICE[b]) if first else ""
            return lead + " & " + name + " & " + " & ".join(cells) + " \\\\"

        # vanilla minus re-run and HOVER minus re-run (CSV stores glide minus X)
        out.append(line(True, "Vanilla", int(v["num_pred_bugs"]), v,
                        -fnum(cv["delta_glide_minus_HOVER"]), -fnum(cv["ci_hi_glide_minus_HOVER"]),
                        -fnum(cv["ci_lo_glide_minus_HOVER"]), fnum(cv["permutation_p"]),
                        holm(cv) or cv["holm_reject"].upper() == "TRUE"))
        out.append(line(False, "\\glide (re-run)", int(g["num_pred_bugs"]), g))
        out.append(line(False, "\\textbf{\\hover} (%s)" % MAIN_MODE[b], int(h["num_pred_bugs"]), h,
                        -fnum(ch["delta_glide_minus_HOVER"]), -fnum(ch["ci_hi_glide_minus_HOVER"]),
                        -fnum(ch["ci_lo_glide_minus_HOVER"]), fnum(ch["permutation_p"]),
                        ch["holm_reject"].upper() == "TRUE"))
        pubrow = {"precision": P, "recall": R, "f1": F1, "f1_iou": FI}
        out.append(line(False, "\\glide (published)", None, pubrow, grey=True))
        if i < len(BACKBONES) - 1:
            out.append("\\midrule")
    write("t1_main", "\n".join(out))


# ===================================================== Tab. 3: decomposition vs re-run
def decomp_main(b):
    g = mrow(b, "glide_official")
    h = mrow(b, "HOVER_" + MAIN_MODE[b])
    hw = mrow(b, "HOVER_whole", "whole")
    gw = rrow(CTRL, b, "E1_glide_controls", "glide_whole")     # GliDe outputs are shared
    F1g, F1h = g["f1"] / 100, h["f1"] / 100
    Ig, Ih = g["f1_iou"] / g["f1"], h["f1_iou"] / h["f1"]
    Igw, Ihw = gw["iou_r"], hw["f1_iou"] / hw["f1"]
    # sanity: GliDe-whole F1 must equal the re-run's F1 (spans do not enter the matching)
    assert abs(gw["f1"] - F1g) < 5e-5, (b, gw["f1"], F1g)
    tot = math.log(h["f1_iou"] / g["f1_iou"])
    parts = {"f1": math.log(F1h / F1g), "frag": math.log(Igw / Ig),
             "match": math.log(Ihw / Igw), "loc": math.log(Ih / Ihw)}
    assert abs(sum(parts.values()) - tot) < 1e-4, (b, parts, tot)
    return {"G": g["f1_iou"], "Gw": 100 * F1g * Igw, "Hw": hw["f1_iou"], "H": h["f1_iou"],
            "Ig": Ig, "Igw": Igw, "Ihw": Ihw, "Ih": Ih, "tot": tot,
            **{"s_" + k: v / tot for k, v in parts.items()}, "dloc": h["f1_iou"] - hw["f1_iou"]}


def t_decomp():
    out = []
    for b in BACKBONES:
        d = decomp_main(b)
        out.append("%s & %s & %s & %s & %s & %s & %s & %s & %s & %s \\\\" % (
            SHORT[b], f2(d["G"]), f2(d["Gw"]), f2(d["Hw"]), f2(d["H"]), sgn(d["dloc"]),
            pc0(d["s_f1"]), pc0(d["s_frag"]), pc0(d["s_match"]), pc0(d["s_loc"])))
    write("t_decomp_rerun", "\n".join(out))


# ===================================================== Tab. 4: controls (main run)
CTRL_ROWS = [  # (tag, variant, label, block)
    ("E1_glide_controls", "glide", "\\glide (re-run)", "G"),
    ("E1_glide_controls", "glide_whole", "\\quad + whole-clip spans", "G"),
    ("E1_glide_controls", "glide_nocopy", "\\quad $-$ prompt-example reports", "G"),
    ("E1_glide_controls", "glide_merge", "\\quad + merge overlapping reports", "G"),
    ("E1_glide_controls", "glide_first", "\\quad + first report per clip", "G"),
    ("E1_glide_controls", "glide_longest", "\\quad + longest report per clip", "G"),
    ("E1_glide_controls", "glide_emit_span", "\\quad + \\hover emission rule", "G"),
    ("E1_glide_controls", "glide_emit_whole", "\\quad + emission rule + whole clip", "G"),
    ("E2_vanilla_controls", "vanilla", "Vanilla", "V"),
    ("E2_vanilla_controls", "vanilla_top1_whole", "\\quad + one report, whole clip", "V"),
    ("E3_constant", "const_glide_example", "Prompt-example sentence", "C"),
    ("E3_constant", "const_generic", "Generic sentence", "C"),
    ("E3_constant", "const_game_loo", "Per-game sentence", "C"),
    ("E3_constant", "const_dev_tfidf", "Dev.\\ medoid, TF-IDF (no judge)", "C"),
    ("E3_constant", "const_dev_medoid", "Dev.\\ medoid, judge-selected (oracle)", "C"),
]


def mark(r):
    if not holm(r):
        return ""
    # delta_ref_minus = HOVER (main run) - variant
    return "$^{\\downarrow}$" if r["delta_ref_minus"] > 0 else "$^{\\uparrow}$"


def t_controls():
    out = []
    # reference rows
    # the controls' reference is the main run itself (checked against Tab. 1)
    for b in BACKBONES:
        ref = 100 * rrow(CTRL, b, "E1_glide_controls", "hover")["f1_iou"]
        assert abs(ref - mrow(b, "HOVER_" + MAIN_MODE[b])["f1_iou"]) < 0.05, (b, ref)
    out.append("\\hover (\\cref{tab:main}) & " + " & ".join(
        f2(mrow(b, "HOVER_" + MAIN_MODE[b])["f1_iou"]) for b in BACKBONES) + " \\\\")
    blocks = {"G": "\\multicolumn{6}{@{}l}{\\emph{Agent outputs, re-used}} \\\\",
              "V": "\\multicolumn{6}{@{}l}{\\emph{Single-call baseline}} \\\\",
              "C": "\\multicolumn{6}{@{}l}{\\emph{One fixed sentence per clip, whole-clip span (no video input)}} \\\\"}
    cur = None
    for tag, var, lab, blk in CTRL_ROWS:
        if blk != cur:
            out.append("\\midrule")
            out.append(blocks[blk])
            cur = blk
        cells = []
        for b in BACKBONES:
            r = rrow(CTRL, b, tag, var)
            cells.append(f2(100 * r["f1_iou"]) + mark(r))
        out.append(lab + " & " + " & ".join(cells) + " \\\\")
    write("t_controls", "\n".join(out))


def t_controls_full():
    """Supp.: every control with counts, P/R/F1/IoU_r, paired test against HOVER (main run).
    Split into the agent block (a) and the vanilla / fixed-sentence blocks (b)."""
    for part, blocks in (("a", ("G",)), ("b", ("V", "C"))):
        out = []
        for i, b in enumerate(BACKBONES):
            rows = [("E1_glide_controls" if part == "a" else "E3_constant", "hover",
                     "\\hover (main run)")] + \
                   [(t, v, l.replace("\\quad ", "\\ \\ ")) for t, v, l, blk in CTRL_ROWS if blk in blocks]
            for j, (tag, var, lab) in enumerate(rows):
                r = rrow(CTRL, b, tag, var)
                lead = ("\\multirow{%d}{*}{\\rotatebox{90}{%s}}" % (len(rows), SHORT[b])) if j == 0 else ""
                d = r["delta_ref_minus"]
                dtxt = "" if d != d else "%s [%s, %s]" % (sgn(-100 * d), sgn(-100 * r["ci_hi"]), sgn(-100 * r["ci_lo"]))
                out.append(" & ".join([lead, lab, "%d" % r["n_videos"], "%d" % r["num_pred_bugs"],
                                       "%.2f" % r["reports_per_clip"], "%d" % r["clips_multi"],
                                       "%.2f" % r["mean_score"], pct(r["precision"]), pct(r["recall"]),
                                       pct(r["f1"]), "%.3f" % r["iou_r"], pct(r["f1_iou"]), dtxt,
                                       pfmt(r["p"]) + ("$^\\dagger$" if holm(r) else "")]) + " \\\\")
            if i < len(BACKBONES) - 1:
                out.append("\\midrule")
        write("s_controls_full_" + part, "\n".join(out))


# ===================================================== Tab. 5: probe, five backbones
def prow(b, sig):
    for r in PROBE:
        if r["backbone"] == b and r["signal"] == sig:
            return {k: fnum(v) for k, v in r.items() if k not in ("backbone", "signal")}
    raise KeyError((b, sig))


def t_probe():
    out = []
    for b in BACKBONES:
        g, h = prow(b, "lo_raw"), prow(b, "hyp_top1")
        out.append("%s & %.3f [%.3f, %.3f] & %.3f [%.3f, %.3f] & %s [%s, %s] & %.3f \\\\" % (
            SHORT[b], g["within_auc"], g["within_lo"], g["within_hi"],
            h["within_auc"], h["within_lo"], h["within_hi"],
            sgn(h["delta_per_video_auc"], 3), sgn(h["delta_lo"], 3), sgn(h["delta_hi"], 3),
            h["wilcoxon_p"]))
    write("t_probe5", "\n".join(out))


def t_probe_full():
    names = [("lo_raw", "generic detector, raw"), ("lo_abs", "generic detector, calibrated"),
             ("hyp_top1", "hypothesis profile, top-1"), ("hyp_max", "hypothesis profile, max")]
    out = []
    for i, b in enumerate(BACKBONES):
        for j, (s, lab) in enumerate(names):
            r = prow(b, s)
            lead = ("\\multirow{4}{*}{%s}" % SHORT[b]) if j == 0 else ""
            out.append("%s & %s & %.3f [%.3f, %.3f] & %.3f [%.3f, %.3f] & %.2f \\\\" % (
                lead, lab, r["within_auc"], r["within_lo"], r["within_hi"],
                r["pooled_auc"], r["pooled_lo"], r["pooled_hi"], r["icc"]))
        if i < len(BACKBONES) - 1:
            out.append("\\midrule")
    write("s_probe5", "\n".join(out))


# ===================================================== Tab. 6: ablation, five backbones
ABL_ROWS = [("no_ctx_calib", "w/o contextual calibration (V)"),
            ("no_hypothesis_scoring", "w/o hypothesis verification (V)"),
            ("no_event_resolution", "w/o event resolution (H)"),
            ("no_utility_selection", "w/o utility selection (U)")]


def amark(r):
    return "$^\\dagger$" if holm(r) else ""


def t_ablation():
    out = ["\\hover (main run) & " + " & ".join(
        f2(100 * rrow(ABL, b, ABL_TAG, "full")["f1_iou"]) for b in BACKBONES) + " \\\\",
        "\\midrule"]
    for var, lab in ABL_ROWS:
        cells = []
        for b in BACKBONES:
            r = rrow(ABL, b, ABL_TAG, var)
            cells.append(sgn(-100 * r["delta_ref_minus"]) + amark(r))
        out.append("\\quad " + lab + " & " + " & ".join(cells) + " \\\\")
    write("t_ablation5", "\n".join(out))


def t_ablation_full():
    out = []
    labs = [("full", "\\hover (full)")] + ABL_ROWS
    for i, b in enumerate(BACKBONES):
        for j, (var, lab) in enumerate(labs):
            r = rrow(ABL, b, ABL_TAG, var)
            lead = ("\\multirow{5}{*}{%s}" % SHORT[b]) if j == 0 else ""
            d = r["delta_ref_minus"]
            dtxt = "" if d != d else "%s [%s, %s]" % (sgn(-100 * d), sgn(-100 * r["ci_hi"]), sgn(-100 * r["ci_lo"]))
            out.append(" & ".join([lead, lab, "%d" % r["num_pred_bugs"], "%.2f" % r["reports_per_clip"],
                                   pct(r["precision"]), pct(r["recall"]), pct(r["f1"]), "%.3f" % r["iou_r"],
                                   pct(r["f1_iou"]), dtxt, pfmt(r["p"]) + amark(r)]) + " \\\\")
        if i < len(BACKBONES) - 1:
            out.append("\\midrule")
    write("s_ablation_full", "\n".join(out))


# ===================================================== Supp.: post-hoc emission x span
def t_posthoc():
    out = []
    for b in BACKBONES:
        ref = [r for r in POST if r["backbone"] == b][0]["reference"]
        cells = []
        for em in ("selector", "top1", "all"):
            for mode in ("window", "frame", "whole"):
                r = rrow(POST, b, "E5_posthoc", "%s_%s" % (em, mode))
                txt = f2(100 * r["f1_iou"])
                if "%s_%s" % (em, mode) == ref:
                    txt = "\\underline{%s}" % txt
                elif holm(r):
                    txt += "$^\\dagger$"
                cells.append(txt)
        nrep = [int(rrow(POST, b, "E5_posthoc", "%s_window" % em)["num_pred_bugs"]) for em in ("selector", "top1", "all")]
        out.append(SHORT[b] + " & " + " & ".join(cells) + " & %d / %d / %d \\\\" % tuple(nrep))
    write("s_posthoc", "\n".join(out))


# ===================================================== Supp.: re-judging
def t_rejudge():
    out = []
    for b in BACKBONES:
        def val(j, m):
            for r in REJ:
                if r["backbone"] == b and r["judging"] == j and r["method"] == m:
                    return r
            raise KeyError((b, j, m))
        hv = [100 * fnum(val(j, "crux")["f1_iou"]) for j in ("A0", "A1", "A2", "A3")]
        gv = [100 * fnum(val(j, "glide_official")["f1_iou"]) for j in ("A0", "A1", "A2", "A3")]
        dv = [100 * fnum(val(j, "glide_official")["delta_ref_minus"]) for j in ("A0", "A1", "A2", "A3")]
        pv = [fnum(val(j, "glide_official")["p"]) for j in ("A0", "A1", "A2", "A3")]
        nrej = sum(str(val(j, "glide_official")["holm_reject"]).lower() == "true" for j in ("A0", "A1", "A2", "A3"))
        rtag = {4: "all", 0: "none"}.get(nrej, "%d of 4" % nrej)
        sdh = 100 * fnum(val("sd_A_repeats", "crux")["f1_iou"])
        sdg = 100 * fnum(val("sd_A_repeats", "glide_official")["f1_iou"])
        sdv = 100 * fnum(val("sd_A_repeats", "vanilla")["f1_iou"])
        kap = [fnum(r["f1_iou"]) for r in REJ if r["backbone"] == b and r["judging"] == "pair_kappa_A_repeat"][0]
        out.append("%s & %s & %.2f & %s & %.2f & %.2f & %s--%s & %s & %.3f \\\\" % (
            SHORT[b], " / ".join(f2(x) for x in hv), sdh, " / ".join(f2(x) for x in gv), sdg, sdv,
            f2(min(dv)), f2(max(dv)), "%s (%s)" % (pfmt(max(pv)), rtag), kap))
    write("s_rejudge", "\n".join(out))


# ===================================================== Supp.: main run vs earlier run
def t_runs():
    out = []
    for b in BACKBONES:
        h = mrow(b, "HOVER_" + MAIN_MODE[b]); c = mcmp(b, "HOVER_" + MAIN_MODE[b])
        a = rrow(E_CTRL, b, "E1_glide_controls", "hover")
        g2 = [r for r in E_REJ if r["backbone"] == b and r["judging"] == "A0" and r["method"] == "glide_official"][0]
        aref = [r for r in E_POST if r["backbone"] == b][0]["reference"].replace("selector_", "")
        out.append(" & ".join([
            NICE[b], MAIN_MODE[b], "%d" % h["num_pred_bugs"], f2(h["precision"]), f2(h["recall"]),
            f2(h["f1_iou"]), "%s (%s%s)" % (sgn(-fnum(c["delta_glide_minus_HOVER"])), pfmt(fnum(c["permutation_p"])),
                                          "$^\\dagger$" if c["holm_reject"].upper() == "TRUE" else ""),
            aref, "%d" % a["num_pred_bugs"], pct(a["precision"]), pct(a["recall"]), pct(a["f1_iou"]),
            "%s (%s%s)" % (sgn(100 * fnum(g2["delta_ref_minus"])), pfmt(fnum(g2["p"])),
                           "$^\\dagger$" if str(g2["holm_reject"]).lower() == "true" else "")]) + " \\\\")
    write("s_runs", "\n".join(out))


# ===================================================== Supp.: decomposition, earlier run
def t_decomp_r2():
    E_DEC = rd(os.path.join(EREV, "revision_decompose.csv"))
    out = []
    for b in BACKBONES:
        r = [x for x in E_DEC if x["backbone"] == b][0]
        f = lambda k: pc0(fnum(r[k]))
        out.append("%s & %.3f & %s & %s & %s & %s \\\\" % (SHORT[b], fnum(r["total_log_ratio"]),
                   f("share_f1"), f("share_glide_fragmentation"), f("share_matched_set"),
                   f("share_hover_localisation")))
    write("s_decomp_r2", "\n".join(out))


# ===================================================== Supp.: segmentation grid
def t_seg():
    out = []
    for b in BACKBONES:
        rows = [r for r in SEG if r["backbone"] == b and not r["tau"].startswith("ref")]
        best = max(rows, key=lambda r: (fnum(r["mean_iou_correct"]), -fnum(r["tau"])))
        g1 = max((r for r in rows if fnum(r["tau"]) >= -1.0), key=lambda r: fnum(r["mean_iou_correct"]))
        low = [r for r in rows if fnum(r["tau"]) == -3.0]
        ref = {r["tau"].split(":")[1]: fnum(r["mean_iou_correct"]) for r in SEG
               if r["backbone"] == b and r["tau"].startswith("ref")}
        lam = lambda r: "$\\infty$" if fnum(r["lambda"]) > 1e6 else "%g" % fnum(r["lambda"])
        tau = lambda r: ("%g" % fnum(r["tau"])).replace("-", "$-$")
        lo_ = "%.3f" % min(fnum(r["mean_iou_correct"]) for r in low)
        hi_ = "%.3f" % max(fnum(r["mean_iou_correct"]) for r in low)
        out.append("%s & (%s, %s) & %.3f & (%s, %s) & %.3f & %s & %.3f & %.3f \\\\" % (
            SHORT[b], tau(g1), lam(g1), fnum(g1["mean_iou_correct"]),
            tau(best), lam(best), fnum(best["mean_iou_correct"]),
            lo_ if lo_ == hi_ else lo_ + "--" + hi_, ref["frame"], ref["whole"]))
    write("s_seg5", "\n".join(out))


def t_seg_q7b():
    rows = [r for r in SEG if r["backbone"] == "qwen2.5-vl-7b" and not r["tau"].startswith("ref")]
    taus = sorted({fnum(r["tau"]) for r in rows})
    lams = sorted({fnum(r["lambda"]) for r in rows})
    best = max(rows, key=lambda r: fnum(r["mean_iou_correct"]))
    out = ["\\begin{tabular}{lcccccc}", "\\toprule",
           "$\\tau$ $\\backslash$ $\\lambda$ & " + " & ".join("$\\infty$" if l > 1e6 else "%g" % l for l in lams) + " \\\\",
           "\\midrule"]
    for t in taus:
        cells = []
        for l in lams:
            r = [x for x in rows if fnum(x["tau"]) == t and fnum(x["lambda"]) == l][0]
            v = "%.3f" % fnum(r["mean_iou_correct"])
            cells.append("\\textbf{%s}" % v if r is best else v)
        out.append(("%g" % t).replace("-", "$-$") + " & " + " & ".join(cells) + " \\\\")
    out += ["\\bottomrule", "\\end{tabular}"]
    write("seg_grid", "\n".join(out))


# ===================================================== timing
def trow(b, m):
    for r in TIME:
        if r["backbone"] == b and r["method"] == m:
            return {k: fnum(v) for k, v in r.items() if k not in ("backbone", "model", "method")}
    raise KeyError((b, m))


def t_time_full_hover():
    """HOVER rows for the three backbones whose per-clip timing logs are summarised only
    in all_backbones_timing.csv (no bootstrap intervals available)."""
    out = []
    for b in ("internvl2.5-4b", "internvl2.5-8b", "ui-tars-1.5-7b"):
        r = trow(b, "hover")
        out.append((b, " & \\hover & %d & %.1f$^\\ast$ & %.1f [%.1f, %.1f] & %.1f & %.2f$^\\ast$ & %.1f & %.1fk & %.0f\\%% \\\\" % (
            r["n_videos"], r["mean_s"], r["median_s"], r["p25_s"], r["p75_s"], r["p90_s"], r["rtf"],
            r["mean_requests"], r["mean_prompt_tokens"] / 1000, 100 * r["model_time_share"])))
    return dict(out)


def t_time_full():
    with open(os.path.join(ROOT, "tables", "time_full.tex")) as f:
        lines = [l.rstrip("\n") for l in f]
    add = t_time_full_hover()
    out, cur = [], None
    names = {NICE[b]: b for b in BACKBONES}
    for l in lines:
        for nm, b in names.items():
            if nm in l and "multirow" in l:
                cur = b
        if l.startswith("\\multirow{2}") and cur in add:
            l = l.replace("\\multirow{2}", "\\multirow{3}")
        if l.strip() == "\\midrule" and cur in add and not any(add[cur] in x for x in out):
            out.append(add[cur])
        out.append(l)
    if cur in add and not any(add[cur] in x for x in out):
        out.append(add[cur])
    write("time_full", "\n".join(out))


def t_medoid_candidates():
    """Supp.: every short-listed development description as a fixed whole-clip prediction."""
    rows = list(csv.DictReader(open(os.path.join(REV, "revision_medoid_candidates.csv"))))
    cells = []
    for r in rows:
        tag = "$^{J}$" if r["judge_pick"] == "1" else ("$^{T}$" if r["tfidf_pick"] == "1" else "")
        cells.append("%d%s & %.2f & %s" % (int(r["rank_tfidf"]) + 1, tag, float(r["dev_mean_rating"]),
                                           f2(100 * float(r["test_f1_iou"]))))
    half = (len(cells) + 1) // 2
    out = []
    for i in range(half):
        right = cells[i + half] if i + half < len(cells) else "& &"
        out.append(cells[i] + " & " + right + " \\\\")
    write("s_medoid", "\n".join(out))


def numbers():
    """Macros used in the text (all derived from the files above)."""
    g = {b: mrow(b, "glide_official")["f1_iou"] for b in BACKBONES}
    h = {b: mrow(b, "HOVER_" + MAIN_MODE[b])["f1_iou"] for b in BACKBONES}
    sp = {b: trow(b, "glide")["mean_s"] / trow(b, "hover")["mean_s"] for b in BACKBONES}
    dloc = {b: decomp_main(b)["dloc"] for b in BACKBONES}
    medoid = 100 * rrow(CTRL, "qwen2.5-vl-3b", "E3_constant", "const_dev_medoid")["f1_iou"]
    lines = ["%% generated by scripts/make_revision_tables.py",
             "\\newcommand{\\timeSpeedMinAll}{%.1f}" % min(sp.values()),
             "\\newcommand{\\timeSpeedMaxAll}{%.1f}" % max(sp.values()),
             "\\newcommand{\\constMedoid}{%.2f}" % medoid,
             "\\newcommand{\\maxLocMain}{%.2f}" % max(dloc.values()),
             "\\newcommand{\\constTfidf}{%.2f}" % (
                 100 * rrow(CTRL, "qwen2.5-vl-3b", "E3_constant", "const_dev_tfidf")["f1_iou"])]
    cand_path = os.path.join(REV, "revision_medoid_candidates.csv")
    cand = [float(r["test_f1_iou"]) * 100 for r in csv.DictReader(open(cand_path))]
    cand.sort()
    pct_ = lambda f: cand[0] + (cand[-1] - cand[0]) * 0 if len(cand) == 1 else \
        (lambda k: cand[int(math.floor(k))] + (cand[min(int(math.floor(k)) + 1, len(cand) - 1)] - cand[int(math.floor(k))]) * (k - math.floor(k)))(f * (len(cand) - 1))
    q = [pct_(f) for f in (0, 0.25, 0.5, 0.75, 1.0)]
    lines += ["\\newcommand{\\constCandN}{%d}" % len(cand),
              "\\newcommand{\\constCandMin}{%.2f}" % q[0],
              "\\newcommand{\\constCandQlo}{%.2f}" % q[1],
              "\\newcommand{\\constCandMedian}{%.2f}" % q[2],
              "\\newcommand{\\constCandQhi}{%.2f}" % q[3],
              "\\newcommand{\\constCandMax}{%.2f}" % q[4]]
    write("revision_numbers", "\n".join(lines))
    print("speed-ups:", {SHORT[b]: round(v, 2) for b, v in sp.items()})
    print("dloc:", {SHORT[b]: round(v, 3) for b, v in dloc.items()})
    for b in BACKBONES:
        d = decomp_main(b)
        print(SHORT[b], {k: round(v, 4) for k, v in d.items()})


if __name__ == "__main__":
    t_main(); t_decomp(); t_controls(); t_controls_full(); t_probe(); t_probe_full()
    t_medoid_candidates(); t_ablation(); t_ablation_full(); t_posthoc(); t_rejudge(); t_runs(); t_decomp_r2()
    t_seg(); t_seg_q7b(); numbers()
