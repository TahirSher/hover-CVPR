"""Regenerate every data figure of the paper from the files in ../data.

Usage:  python scripts/make_figures.py      (run from the paper root)

All numbers are read from the evaluation outputs; nothing is typed in by hand
except the published UAL-Bench reference values (Abdullah et al., WACV 2025,
Table 3) and the published GliDe results (Zheng et al., VideoGlitchBench, Table 3),
which are marked as such below.
"""
import csv
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

for _f in ["/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyretermes-regular.otf",
           "/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyretermes-bold.otf",
           "/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyretermes-italic.otf"]:
    if os.path.exists(_f):
        font_manager.fontManager.addfont(_f)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
FIGS = os.path.join(ROOT, "figs")
os.makedirs(FIGS, exist_ok=True)

# Validated categorical palette (blue / orange / aqua) + neutral grays.
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
GRAY, LGRAY, INK, MUTED = "#8a8a85", "#d4d3cf", "#222220", "#5f5e5a"
NAVY = "#153e75"

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["TeX Gyre Termes", "Times New Roman", "Times", "Nimbus Roman",
                                            "DejaVu Serif"],
    "mathtext.fontset": "stix", "font.size": 7.5, "axes.titlesize": 8,
    "axes.labelsize": 7.5, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "legend.fontsize": 6.8, "axes.edgecolor": MUTED, "axes.linewidth": 0.6,
    "xtick.color": MUTED, "ytick.color": MUTED, "axes.labelcolor": INK,
    "text.color": INK, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})
COL, FULL = 3.25, 6.875

BACKBONES = ["qwen2.5-vl-3b", "qwen2.5-vl-7b", "internvl2.5-4b", "internvl2.5-8b",
             "ui-tars-1.5-7b"]
NICE = {"qwen2.5-vl-3b": "Qwen2.5-VL-3B", "qwen2.5-vl-7b": "Qwen2.5-VL-7B",
        "internvl2.5-4b": "InternVL2.5-4B", "internvl2.5-8b": "InternVL2.5-8B",
        "ui-tars-1.5-7b": "UI-TARS-1.5-7B"}
SHORT = {"qwen2.5-vl-3b": "Q-3B", "qwen2.5-vl-7b": "Q-7B", "internvl2.5-4b": "I-4B",
         "internvl2.5-8b": "I-8B", "ui-tars-1.5-7b": "UT-7B"}


def read_csv(name):
    with open(os.path.join(DATA, name)) as f:
        return list(csv.DictReader(f))


MASTER = read_csv("master_metrics_all.csv")
SEL = {r["backbone"]: r for r in read_csv("selector_quality.csv")
       if r["calibration_mode"] == r["selected_refine_mode"]}
CMP = read_csv("all_mode_comparisons.csv")


# PUBLISHED: GliDe results (Zheng et al., VideoGlitchBench, Table 3): F1 and F1xIoU in %.
# These are the GliDe numbers of main Tab. 1; our same-stack re-run is "glide_official".
GLIDE_PUB = {"qwen2.5-vl-3b": (35.52, 17.29), "qwen2.5-vl-7b": (39.12, 19.46),
             "internvl2.5-4b": (32.56, 15.27), "internvl2.5-8b": (36.33, 17.04),
             "ui-tars-1.5-7b": (40.45, 17.02)}


def metric(backbone, mode, method):
    for r in MASTER:
        if r["backbone"] == backbone and r["refine_mode"] == mode and r["method"] == method:
            return {k: float(v) for k, v in r.items()
                    if k not in ("backbone", "refine_mode", "method") and v != ""}
    raise KeyError((backbone, mode, method))


def selected_mode(b):
    return SEL[b]["selected_refine_mode"]


def comparison(b, mode):
    for r in CMP:
        if r["backbone"] == b and r["refine_mode"] == mode and "HOVER" in r["comparison"]:
            return r
    raise KeyError(b)


def save(fig, name):
    fig.savefig(os.path.join(FIGS, name + ".pdf"))
    fig.savefig(os.path.join(FIGS, name + ".png"), dpi=220)
    plt.close(fig)


# ---------------------------------------------------------------------------
# Fig. 1 (teaser): F1xIoU per backbone, vanilla -> GliDe -> HOVER, plus the
# HOVER whole-video control.
# ---------------------------------------------------------------------------
def fig_teaser():
    fig, ax = plt.subplots(figsize=(COL, 2.05))
    ys = np.arange(len(BACKBONES))[::-1]
    for y, b in zip(ys, BACKBONES):
        m = selected_mode(b)
        v = metric(b, m, "vanilla")["f1_iou"]
        gr = metric(b, m, "glide_official")["f1_iou"]
        gp = GLIDE_PUB[b][1]
        h = metric(b, m, f"HOVER_{m}")["f1_iou"]
        w = metric(b, "whole", "HOVER_whole")["f1_iou"]
        c = comparison(b, m)
        ax.plot([gp, h], [y, y], color=LGRAY, lw=2.2, zorder=1, solid_capstyle="round")
        ax.scatter([v], [y], s=16, color=GRAY, zorder=3, marker="o", linewidths=0)
        ax.scatter([gr], [y], s=22, facecolors="white", edgecolors=ORANGE, zorder=3, marker="s",
                   linewidths=0.9)
        ax.scatter([gp], [y], s=22, color=ORANGE, zorder=3, marker="s", linewidths=0)
        ax.scatter([w], [y], s=34, facecolors="white", edgecolors=BLUE, zorder=4,
                   marker="D", linewidths=0.9)
        ax.scatter([h], [y], s=26, color=BLUE, zorder=5, marker="o", linewidths=0)
        sig = c["holm_reject"].strip().lower() == "true"
        d_rr = float(c["delta_HOVER_minus_glide"])
        d_pub = round(h, 2) - gp
        ax.text(max(h, w, gr) + 0.8, y, f"+{d_pub:.1f} (+{d_rr:.1f}" + ("$^{\\ast}$" if sig else "") + ")",
                va="center", ha="left", fontsize=6.6, color=INK)
    ax.set_yticks(ys)
    ax.set_yticklabels([NICE[b] for b in BACKBONES])
    ax.set_xlabel(r"F1$\times$IoU (%) on the VideoGlitchBench test split")
    ax.set_xlim(0, 44)
    ax.set_xticks([0, 5, 10, 15, 20, 25, 30, 35])
    ax.grid(axis="x", color=LGRAY, lw=0.4, zorder=0)
    ax.tick_params(axis="y", length=0)
    from matplotlib.lines import Line2D
    hs = [Line2D([], [], color=GRAY, marker="o", ls="", ms=4, label="Vanilla VLM"),
          Line2D([], [], color=ORANGE, marker="s", ls="", ms=4, label="GliDe (published)"),
          Line2D([], [], mfc="white", mec=ORANGE, marker="s", ls="", ms=4, label="GliDe (re-run)"),
          Line2D([], [], color=BLUE, marker="o", ls="", ms=4.5, label="HOVER"),
          Line2D([], [], mfc="white", mec=BLUE, marker="D", ls="", ms=4.5,
                 label="HOVER, whole-video spans")]
    ax.legend(handles=hs, loc="lower center", bbox_to_anchor=(0.45, 1.0), ncol=3,
              frameon=False, handletextpad=0.3, columnspacing=0.9)
    save(fig, "teaser_results")


# ---------------------------------------------------------------------------
# Decomposition: F1xIoU = F1 x IoU_r (rating-weighted IoU), exact.
# ---------------------------------------------------------------------------
def fig_decomposition():
    fig, ax = plt.subplots(figsize=(COL, 2.35))
    f = np.linspace(1, 72, 300)
    for c in (5, 10, 15, 20, 25, 30):
        ax.plot(f, c / f, color=LGRAY, lw=0.5, zorder=0)
        x0 = c / 0.535
        if 4 < x0 < 69:
            ax.text(x0, 0.536, f"{c}", fontsize=5.6, color=GRAY, ha="center", va="bottom")
    ax.text(70, 0.552, r"iso-F1$\times$IoU contours", fontsize=5.6, color=GRAY, ha="right")
    # label offsets (dx, dy, ha) chosen to avoid collisions
    off_h = {"qwen2.5-vl-3b": (1.2, 0.006, "left"), "qwen2.5-vl-7b": (0.0, 0.012, "center"),
             "internvl2.5-4b": (0.6, 0.017, "center"), "internvl2.5-8b": (0.6, -0.016, "left"),
             "ui-tars-1.5-7b": (0.0, -0.022, "center")}
    # offsets for the published-GliDe labels
    off_g = {"qwen2.5-vl-3b": (-1.0, 0.000, "right"), "qwen2.5-vl-7b": (0.0, 0.011, "center"),
             "internvl2.5-4b": (-1.0, 0.000, "right"), "internvl2.5-8b": (0.0, -0.012, "center"),
             "ui-tars-1.5-7b": (-1.2, 0.000, "right")}
    for b in BACKBONES:
        m = selected_mode(b)
        pts = {}
        for key, meth, mode in [("v", "vanilla", m), ("r", "glide_official", m),
                                ("h", f"HOVER_{m}", m), ("w", "HOVER_whole", "whole")]:
            r = metric(b, mode, meth)
            pts[key] = (r["f1"], r["f1_iou"] / r["f1"])
        f1p, fip = GLIDE_PUB[b]
        pts["g"] = (f1p, fip / f1p)
        ax.annotate("", xy=pts["h"], xytext=pts["r"],
                    arrowprops=dict(arrowstyle="-|>", color=GRAY, lw=0.8,
                                    shrinkA=3, shrinkB=4, mutation_scale=6), zorder=1)
        ax.scatter(*pts["g"], s=14, color=ORANGE, marker="s", zorder=2, linewidths=0, alpha=0.3)
        ax.scatter(*pts["r"], s=16, facecolors="white", edgecolors=ORANGE, marker="s", zorder=3,
                   linewidths=0.7)
        ax.scatter(*pts["w"], s=26, facecolors="white", edgecolors=BLUE, marker="D",
                   zorder=4, linewidths=0.8)
        ax.scatter(*pts["h"], s=18, color=BLUE, zorder=5, linewidths=0)
        ax.scatter(*pts["v"], s=12, color=GRAY, zorder=2, linewidths=0)
        dx, dy, ha = off_h[b]
        ax.text(pts["h"][0] + dx, pts["h"][1] + dy, SHORT[b], fontsize=5.8, color=INK, ha=ha,
                va="center")
        dx, dy, ha = off_g[b]
        ax.text(pts["r"][0] + dx, pts["r"][1] + dy, SHORT[b], fontsize=5.8, color=MUTED, ha=ha,
                va="center")
    ax.set_xlim(0, 72)
    ax.set_ylim(0.28, 0.56)
    ax.set_xlabel("F1 (%)  [description quality and emission]")
    ax.set_ylabel(r"$\overline{\mathrm{IoU}}_r$  [grounding]")
    from matplotlib.lines import Line2D
    hs = [Line2D([], [], color=GRAY, marker="o", ls="", ms=3.5, label="Vanilla"),
          Line2D([], [], color=ORANGE, marker="s", ls="", ms=3.5, alpha=0.3, label="GliDe (published)"),
          Line2D([], [], mfc="white", mec=ORANGE, marker="s", ls="", ms=3.5, label="GliDe (re-run)"),
          Line2D([], [], color=BLUE, marker="o", ls="", ms=3.5, label="HOVER"),
          Line2D([], [], mfc="white", mec=BLUE, marker="D", ls="", ms=3.8,
                 label="HOVER, whole video")]
    ax.legend(handles=hs, loc="lower right", frameon=False, ncol=1, handletextpad=0.2,
              borderaxespad=0.1)
    save(fig, "decomposition")


# ---------------------------------------------------------------------------
# Verification profiles of four test videos (Qwen2.5-VL-7B).
# ---------------------------------------------------------------------------
def fig_profiles():
    ex = json.load(open(os.path.join(DATA, "profile_examples_qwen7b.json")))
    order = ["gl4xz6", "5d9s4z", "6nxmsd", "do7rnc"]
    fig, axs = plt.subplots(1, 4, figsize=(FULL, 1.55), sharey=True)
    for ax, vid in zip(axs, order):
        e = ex[vid]
        h = e["hypotheses"][0]
        s = np.asarray(h["profile"])
        T = s.size
        dur = e["duration"]
        t = (np.arange(T) + 0.5) * dur / T
        width = dur / T
        cols = [BLUE if x > e["tau"] else LGRAY for x in s]
        ax.bar(t, s, width=width * 0.82, color=cols, linewidth=0, zorder=2)
        ax.axhline(e["tau"], color=ORANGE, lw=0.8, ls=(0, (3, 2)), zorder=3)
        ax.axhline(0, color=MUTED, lw=0.4, zorder=1)
        for rep in e["reports"][:1]:
            for a, b in rep["spans"]:
                ax.axvspan(a, b, ymin=0.0, ymax=0.06, color=NAVY, alpha=1.0, lw=0)
        for m in h["members"]:
            ax.scatter([(m + 0.5) * width], [s.max() + 0.55], marker="v", s=9, color=AQUA,
                       zorder=4, linewidths=0)
        ax.set_xlim(0, dur)
        ax.set_title(f"{e['game']} ({vid})", fontsize=6.6, pad=2)
        ax.set_xlabel("time (s)")
        ax.grid(axis="y", color=LGRAY, lw=0.3)
    axs[0].set_ylabel(r"$s_h(t)$ (log-odds)")
    axs[0].set_ylim(-5.6, 4.6)
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    hs = [Patch(color=BLUE, label=r"window above $\tau$"),
          Patch(color=LGRAY, label=r"window below $\tau$"),
          Line2D([], [], color=ORANGE, ls=(0, (3, 2)), lw=0.8, label=r"$\tau$"),
          Line2D([], [], color=AQUA, marker="v", ls="", ms=3.5,
                 label="windows that proposed $h$"),
          Patch(color=NAVY, label="emitted span")]
    fig.legend(handles=hs, loc="lower center", bbox_to_anchor=(0.5, 0.97), ncol=5,
               frameon=False, handletextpad=0.4, columnspacing=1.2)
    save(fig, "profiles")


# ---------------------------------------------------------------------------
# Span coverage of emitted predictions (fraction of the video covered).
# ---------------------------------------------------------------------------
def fig_coverage():
    st = json.load(open(os.path.join(DATA, "run_stats.json")))
    fig, axs = plt.subplots(1, 5, figsize=(FULL, 1.45), sharey=True)
    for ax, b in zip(axs, BACKBONES):
        for key, col, lab in [("glide", ORANGE, "GliDe"), ("hover", BLUE, "HOVER")]:
            c = np.sort(np.asarray(st[b][key]["coverage"]))
            y = np.arange(1, c.size + 1) / c.size
            ax.step(c, y, where="post", color=col, lw=1.2, label=lab)
        ax.set_title(NICE[b], fontsize=6.8, pad=2)
        ax.set_xlim(0, 1.0)
        ax.set_ylim(0, 1.0)
        ax.set_xlabel("span / video length")
        ax.grid(color=LGRAY, lw=0.3)
    axs[0].set_ylabel("ECDF of predictions")
    axs[0].legend(loc="upper left", frameon=False)
    save(fig, "coverage")


# ---------------------------------------------------------------------------
# Selector quality vs final F1xIoU.
# ---------------------------------------------------------------------------
def fig_selector():
    fig, axs = plt.subplots(1, 2, figsize=(COL * 1.9, 1.75))
    ax = axs[0]
    for b in BACKBONES:
        r = SEL[b]
        m = selected_mode(b)
        auc, lo, hi = float(r["selector_oof_auc"]), float(r["selector_oof_lo"]), float(r["selector_oof_hi"])
        h = metric(b, m, f"HOVER_{m}")["f1_iou"]
        ax.errorbar(auc, h, xerr=[[auc - lo], [hi - auc]], fmt="o", color=BLUE, ms=3.5,
                    elinewidth=0.7, capsize=1.5)
        ax.text(auc + 0.008, h + 0.35, SHORT[b], fontsize=5.8)
    ax.axvline(0.5, color=GRAY, lw=0.5, ls=":")
    ax.set_xlabel("selector out-of-fold AUC (development, 95% game-cluster CI)")
    ax.set_ylabel(r"HOVER F1$\times$IoU (%) on test")
    ax.set_xlim(0.40, 0.95)
    ax.grid(color=LGRAY, lw=0.3)
    ax = axs[1]
    x = np.arange(len(BACKBONES))
    wdt = 0.26
    keys = [("f1_iou_emit_all", LGRAY, "emit all"), ("f1_iou_emit_top1", ORANGE, "emit top-1"),
            ("f1_iou_selected", BLUE, "utility selector")]
    for k, (key, col, lab) in enumerate(keys):
        ax.bar(x + (k - 1) * wdt, [100 * float(SEL[b][key]) for b in BACKBONES], width=wdt * 0.92,
               color=col, label=lab, linewidth=0)
    ax.set_xticks(x)
    ax.set_xticklabels([SHORT[b] for b in BACKBONES])
    ax.set_ylabel(r"development F1$\times$IoU, out-of-fold (%)")
    ax.legend(frameon=False, loc="lower center", bbox_to_anchor=(0.5, 0.98), ncol=3)
    ax.set_ylim(0, 33)
    ax.grid(axis="y", color=LGRAY, lw=0.3)
    fig.tight_layout(w_pad=1.5)
    save(fig, "selector")


# ---------------------------------------------------------------------------
# Ablation on Qwen2.5-VL-3B (only backbone with judged ablations).
# ---------------------------------------------------------------------------
def fig_ablation():
    rows = []
    with open(os.path.join(DATA, "ablation_qwen2.5-vl-3b.csv"), encoding="latin-1") as f:
        lines = f.read().splitlines()
    start = [i for i, l in enumerate(lines) if l.startswith("Method,")][0]
    for l in lines[start + 1:]:
        p = l.split(",")
        if len(p) > 6 and p[0]:
            rows.append((p[0], float(p[5]), p[6]))
    lab = {"glide_official": "GliDe (re-run)", "crux": "HOVER (full)", "vanilla": "Vanilla",
           "crux_no_ctx_calib": "w/o contextual calibration",
           "crux_no_event_resolution": "w/o event resolution",
           "crux_no_hypothesis_scoring": "w/o hypothesis verification",
           "crux_no_segmentation": "w/o segmentation",
           "crux_no_subframe": "w/o sub-frame refinement",
           "crux_no_utility_selection": "w/o utility selection"}
    order = ["crux", "crux_no_ctx_calib", "crux_no_hypothesis_scoring", "crux_no_segmentation",
             "crux_no_subframe", "crux_no_event_resolution", "crux_no_utility_selection",
             "glide_official", "vanilla"]
    d = {r[0]: r for r in rows}
    fig, ax = plt.subplots(figsize=(COL, 2.0))
    ys = np.arange(len(order))[::-1]
    full = d["crux"][1]
    for y, k in zip(ys, order):
        v = d[k][1]
        col = BLUE if k.startswith("crux") else (ORANGE if k == "glide_official" else GRAY)
        ax.barh(y, v, height=0.62, color=col, linewidth=0)
        txt = f"{v:.2f}"
        if k.startswith("crux") and k != "crux":
            txt += f"  ({v - full:+.2f})"
        ax.text(v + 0.4, y, txt, va="center", fontsize=6.2)
    ax.set_yticks(ys)
    ax.set_yticklabels([lab[k] for k in order])
    ax.set_xlim(0, 40)
    ax.set_xlabel(r"F1$\times$IoU (%), Qwen2.5-VL-3B, test")
    ax.tick_params(axis="y", length=0)
    ax.grid(axis="x", color=LGRAY, lw=0.3)
    save(fig, "ablation")


# ---------------------------------------------------------------------------
# UAL-Bench: onset accuracy (within 1 s) against the whole-video reference.
# Published values: Abdullah et al., WACV 2025, Table 3 (BLIP2-LLaMA3 and
# VideoLLaMA-LLaMA3, the best published VLM-LLM entries).
# ---------------------------------------------------------------------------
PUBLISHED_ONSET_1S = {"uag_oops": {"BLIP2-LLaMA3": 39.33, "VideoLLaMA-LLaMA3": 38.07},
                      "uag_funqa": {"BLIP2-LLaMA3": 38.37, "VideoLLaMA-LLaMA3": 41.28},
                      "uag_ssbd": {"BLIP2-LLaMA3": 4.81, "VideoLLaMA-LLaMA3": 8.65}}


def load_ual():
    out = {}
    for fn in sorted(os.listdir(os.path.join(DATA, "ual"))):
        d = json.load(open(os.path.join(DATA, "ual", fn)))
        for sub, v in d["subsets"].items():
            for b, o in v["official"].items():
                out[(sub, b)] = (o, v["whole_video_reference"])
    return out


def fig_ual():
    U = load_ual()
    subs = [("uag_oops", "UAG-OOPS"), ("uag_funqa", "UAG-FunQA"), ("uag_ssbd", "UAG-SSBD")]
    bbs = ["qwen2.5-vl-7b", "internvl2.5-8b", "ui-tars-1.5-7b"]
    fig, axs = plt.subplots(1, 3, figsize=(FULL, 1.55), sharey=False)
    for ax, (s, name) in zip(axs, subs):
        whole = U[(s, bbs[0])][1]["onset_acc_1s"]
        vals = [U[(s, b)][0]["onset_acc_1s"] for b in bbs]
        x = np.arange(len(bbs))
        ax.bar(x, vals, width=0.6, color=BLUE, linewidth=0, label="HOVER localisation core")
        for xi, v in zip(x, vals):
            ax.text(xi, v * 0.5, f"{v:.1f}", ha="center", va="center", fontsize=6.4,
                    color="white")
        ax.axhline(whole, color=GRAY, lw=0.9, ls="--", label="whole-video span")
        pub = PUBLISHED_ONSET_1S[s]
        best = max(pub.values())
        ax.axhline(best, color=ORANGE, lw=0.9, ls=":", label="best published VLM-LLM")
        ax.set_xticks(x)
        ax.set_xticklabels([SHORT[b] for b in bbs])
        ax.set_title(name, fontsize=7, pad=2)
        ax.set_ylim(0, max(max(vals), best, whole) * 1.25 + 2)
        ax.grid(axis="y", color=LGRAY, lw=0.3)
    axs[0].set_ylabel("onset acc. within 1 s (%)")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", bbox_to_anchor=(0.5, 0.98), ncol=3, frameon=False)
    fig.tight_layout(w_pad=1.2)
    save(fig, "ual_onset")


# ---------------------------------------------------------------------------
# Cost: VLM calls per video and by stage.
# ---------------------------------------------------------------------------
def fig_cost():
    fig, ax = plt.subplots(figsize=(COL, 1.6))
    x = np.arange(len(BACKBONES))
    wdt = 0.2
    for k, (mode, col) in enumerate([("window", AQUA), ("frame", BLUE)]):
        vals = [metric(b, mode, f"HOVER_{mode}")["calls_per_video"] for b in BACKBONES]
        ax.bar(x + (k - 1.5) * wdt, vals, width=wdt * 0.92, color=col, label=f"HOVER ({mode})",
               linewidth=0)
    vals = [metric(b, "frame", "vanilla")["calls_per_video"] for b in BACKBONES]
    ax.bar(x + 0.5 * wdt, vals, width=wdt * 0.92, color=GRAY, label="Vanilla", linewidth=0)
    tim = {r["backbone"]: r for r in read_csv(os.path.join("timing", "all_backbones_timing.csv"))
           if r["method"] == "glide"}
    gl = [float(tim[b]["mean_requests"]) for b in BACKBONES]
    ax.bar(x + 1.5 * wdt, gl, width=wdt * 0.92, color=ORANGE, label="GliDe (re-run, requests)",
           linewidth=0)
    for xi, v in zip(x, gl):
        ax.text(xi + 1.5 * wdt, v + 2, f"{v:.0f}", ha="center", va="bottom", fontsize=5.6)
    ax.set_xticks(x)
    ax.set_xticklabels([SHORT[b] for b in BACKBONES])
    ax.set_ylabel("VLM calls / video")
    ax.set_ylim(0, 165)
    ax.legend(frameon=False, ncol=2, loc="upper center", bbox_to_anchor=(0.5, 1.30))
    ax.grid(axis="y", color=LGRAY, lw=0.3)
    save(fig, "cost")


if __name__ == "__main__":
    fig_teaser()
    fig_decomposition()
    fig_profiles()
    fig_coverage()
    fig_selector()
    fig_ual()
    fig_cost()
    print("figures written to", FIGS)
