"""Qualitative figure from real VideoGlitchBench clips (needs the videos locally).

For each requested clip the figure shows a strip of frames sampled across the
clip, and underneath it three timelines: ground truth, GliDe and HOVER, each
with its spans and (abridged) description. Nothing is drawn that is not in the
annotation file or in the run files.

Example:
  python scripts/make_qualitative.py \
      --video_root /path/VideoGlitchBench/raw \
      --annotations /path/VideoGlitchBench/annotations.json \
      --hover_run  /path/HOVER_v8_work/v10/runs/qwen2.5-vl-7b/HOVER_window_test_batch_report.json \
      --glide_run  /path/HOVER_v8_work/v10/runs/qwen2.5-vl-7b/glide_official_test.json \
      --clips "Dishonored 2::5d9s4z" "Assassin's Creed II::gl4xz6" \
      --out figs/qualitative.pdf

Then add to supp.tex (or main.tex):
  \\begin{figure*}[t]\\centering
  \\includegraphics[width=\\textwidth]{figs/qualitative.pdf}
  \\caption{...}\\end{figure*}
"""
import argparse
import glob
import json
import os
import textwrap

import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

BLUE, ORANGE, INK, LGRAY = "#2a78d6", "#eb6834", "#222220", "#d4d3cf"
GT_COLOR = "#1baf7a"
plt.rcParams.update({"font.family": "serif", "font.serif": ["TeX Gyre Termes", "Times New Roman", "DejaVu Serif"], "pdf.fonttype": 42})


def load_any(path):
    d = json.load(open(path))
    if isinstance(d, dict):
        d = d.get("outputs", d.get("data", d.get("records", [])))
    out = {}
    for r in d:
        name = str(r.get("video_name", "")).replace(".mp4", "")
        game = r.get("game_name") or r.get("game") or ""
        out[(game, name)] = r
        out[("", name)] = r
    return out


def spans_of(rec):
    """Return list of (description, [[a, b], ...]) for one record."""
    if rec is None or rec.get("no_bugs"):
        return []
    bugs = rec.get("bugs") or []
    tns = rec.get("time_nodes") or []
    if isinstance(bugs, str):
        bugs = [bugs]
    out = []
    for i, b in enumerate(bugs):
        t = tns[i] if i < len(tns) else []
        if t and isinstance(t[0], (int, float)):
            t = [t]
        out.append((str(b), [[float(x[0]), float(x[1])] for x in t]))
    return out


def find_video(root, game, name):
    for c in [os.path.join(root, game, name + ".mp4"), os.path.join(root, name + ".mp4")]:
        if os.path.exists(c):
            return c
    hits = glob.glob(os.path.join(root, "*", name + ".mp4"))
    return hits[0] if hits else None


def read_frames(path, n):
    cap = cv2.VideoCapture(path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    dur = total / fps
    frames, times = [], []
    for t in np.linspace(0, dur, n + 2)[1:-1]:
        cap.set(cv2.CAP_PROP_POS_MSEC, 1000.0 * t)
        ok, img = cap.read()
        if ok:
            frames.append(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
            times.append(t)
    cap.release()
    return frames, times, dur


def draw_track(ax, items, dur, color, label):
    ax.set_xlim(0, dur)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.text(-0.01 * dur, 0.77, label, ha="right", va="center", fontsize=7, color=INK)
    ax.add_patch(plt.Rectangle((0, 0.62), dur, 0.3, color=LGRAY, lw=0))
    for _, sp in items:
        for a, b in sp:
            ax.add_patch(plt.Rectangle((a, 0.62), max(b - a, dur * 0.004), 0.3, color=color, lw=0))
    txt = " | ".join(textwrap.shorten(d, 150, placeholder="...") for d, _ in items[:2]) if items \
        else "(no glitch reported)"
    ax.text(0, 0.45, txt, ha="left", va="top", fontsize=5.4, color=INK)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--video_root", required=True)
    p.add_argument("--annotations", required=True)
    p.add_argument("--hover_run", required=True)
    p.add_argument("--glide_run", required=True)
    p.add_argument("--clips", nargs="+", required=True, help='"Game::video_name" entries')
    p.add_argument("--n_frames", type=int, default=6)
    p.add_argument("--out", default="figs/qualitative.pdf")
    a = p.parse_args()

    gt, hv, gl = load_any(a.annotations), load_any(a.hover_run), load_any(a.glide_run)
    n = len(a.clips)
    fig = plt.figure(figsize=(6.875, 2.25 * n))
    outer = fig.add_gridspec(n, 1, hspace=0.45)
    for k, clip in enumerate(a.clips):
        game, name = clip.split("::") if "::" in clip else ("", clip)
        name = name.replace(".mp4", "")
        path = find_video(a.video_root, game, name)
        if path is None:
            raise SystemExit(f"video not found for {clip}")
        frames, times, dur = read_frames(path, a.n_frames)
        g = outer[k].subgridspec(4, a.n_frames, height_ratios=[3.2, 0.75, 0.75, 0.75], hspace=0.05,
                                 wspace=0.03)
        for j, (im, t) in enumerate(zip(frames, times)):
            ax = fig.add_subplot(g[0, j])
            ax.imshow(im)
            ax.set_xticks([])
            ax.set_yticks([])
            for s in ax.spines.values():
                s.set_visible(False)
            ax.set_title(f"{t:.1f} s", fontsize=6, pad=1)
            if j == 0:
                ax.set_ylabel(f"{game}\n({name})", fontsize=6.5)
        for row, (src, col, lab) in enumerate([(gt, GT_COLOR, "Ground truth"),
                                               (gl, ORANGE, "GliDe"),
                                               (hv, BLUE, "HOVER")], start=1):
            ax = fig.add_subplot(g[row, :])
            rec = src.get((game, name)) or src.get(("", name))
            draw_track(ax, spans_of(rec), dur, col, lab)
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    fig.savefig(a.out, bbox_inches="tight")
    fig.savefig(a.out.rsplit(".", 1)[0] + ".png", dpi=220, bbox_inches="tight")
    print("wrote", a.out)


if __name__ == "__main__":
    main()
