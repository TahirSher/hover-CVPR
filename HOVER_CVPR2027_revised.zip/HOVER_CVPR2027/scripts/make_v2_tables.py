"""Tables and macros of the second revision, from data/v2 (outputs of v2_analyses.py, score_v2.py,
timing_v2.py in the code release). Run after make_revision_tables.py (it overwrites t1_main.tex):

    python scripts/make_v2_tables.py

Inputs (data/v2/)
  v2_methods.csv, v2_tests.csv       every method under the released evaluator ('rating') and under
                                     rating x IoU matching ('rxiou'); paired tests with exact game-level
                                     p, percentile and leave-one-game-out jackknife t(11) intervals
  v2_detection.csv                   clip-level detection on the 76 glitch-free test clips
  v2_subset.csv                      clips whose glitch covers < 50% / < 30% of the clip
  v2_honly.csv, v2_honly_tests.csv   stage H only (top-1, whole clip): glitch-definition test, dev split
  v2_newbb.csv, v2_newbb_tests.csv   Qwen3-VL-8B and Qwen2.5-VL-32B (HOVER and vanilla only)
  v2_timing_per_video.csv            re-timing of the scored configurations (100 clips)
  v2_*_j2.csv                        the same analyses with a second judge (Qwen2.5-72B-Instruct-AWQ)
  v3_controls*.csv, v3_detection.csv  shuffled descriptions and abstention (third revision)
  v3_glide_clean*.csv                GliDe re-run without tracker memory failures (Q-3B, I-8B, UT-7B)
  v3_full*.csv                       core and vanilla on all 5,238 clips
  v3_human_*.csv                     blinded two-annotator check of both judges
  v4_multi.csv, v4_games.csv,        clips with one vs. several glitches, per-game differences against the
  v4_gtstats.csv                     re-run, glitches per clip on the whole benchmark (v4_reviewer.py)
  v4_splitstats.csv                  the 12 development, 12 test and 96 unused games compared (v4_split_stats.py)
  v4_timing_paired_stats.csv         same-session timing of vanilla, GliDe, the core and HOVER (paired_timing.sh,
                                     v4_timing_paired_stats.py; per-clip times in v4_timing_paired_per_clip.csv)
Files that do not exist yet are skipped; their table cells print '--'.
"""
import csv
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from make_revision_tables import (BACKBONES, NICE, SHORT, MAIN_MODE, GLIDE_PUB, f2, sgn, pfmt, write,  # noqa: E402
                                  rhu, DATA)

V2 = os.path.join(DATA, "v2")


def rd(name):
    p = os.path.join(V2, name)
    return list(csv.DictReader(open(p, encoding="utf-8"))) if os.path.exists(p) else []


def fl(x):
    return float(x) if x not in ("", None) else float("nan")


METH, TESTS, DET, SUB = rd("v2_methods.csv"), rd("v2_tests.csv"), rd("v2_detection.csv"), rd("v2_subset.csv")
HON, HONT = rd("v2_honly.csv"), rd("v2_honly_tests.csv")
NEWB, NEWBT = rd("v2_newbb.csv"), rd("v2_newbb_tests.csv")
METH2, TESTS2 = rd("v2_methods_j2.csv"), rd("v2_tests_j2.csv")
V3C, V3T, V3D = rd("v3_controls.csv"), rd("v3_controls_tests.csv"), rd("v3_detection.csv")
CLEAN_BB = ("qwen2.5-vl-3b", "internvl2.5-8b", "ui-tars-1.5-7b")   # re-run anew without tracker OOM
_csfx = lambda b: "" if b == "internvl2.5-8b" else "_" + b
GC = {(b, j): {r["method"]: r for r in rd("v3_glide_clean%s%s.csv" % (_csfx(b), j))} for b in CLEAN_BB for j in ("", "_j2")}
GCT = {(b, j): rd("v3_glide_clean_tests%s%s.csv" % (_csfx(b), j)) for b in CLEAN_BB for j in ("", "_j2")}
FULL, FULLT = rd("v3_full.csv"), rd("v3_full_tests.csv")
HAG, HME, HJU = rd("v3_human_agreement.csv"), rd("v3_human_methods.csv"), rd("v3_human_judges.csv")
V4M, V4G, V4S = rd("v4_multi.csv"), rd("v4_games.csv"), rd("v4_gtstats.csv")
V4SPLIT = rd("v4_splitstats.csv")
V4TP = rd("v4_timing_paired_stats.csv")


def meth(b, m, rule="rating", rows=None):
    for r in rows if rows is not None else METH:
        if r["backbone"] == b and r["method"] == m and r["rule"] == rule:
            return r
    return None


def test(b, ref, var, rule="rating", rows=None):
    for r in rows if rows is not None else TESTS:
        if r["backbone"] == b and r["ref"] == ref and r["var"] == var and r["rule"] == rule:
            return r
    return None


def holm(ps, alpha=0.05):
    """Holm over a family {key: p}; returns {key: reject}."""
    items = sorted(ps.items(), key=lambda kv: kv[1])
    out, still = {}, True
    for i, (k, p) in enumerate(items):
        still = still and p <= alpha / (len(items) - i)
        out[k] = still
    return out


def dcell(t, sign=1.0, rej=False):
    """Delta [jackknife t(11) 95% CI] and p, in points; sign flips ref-var orientation."""
    if t is None:
        return "--", "--"
    d, lo, hi = sign * 100 * fl(t["delta"]), 100 * fl(t["jk_lo"]), 100 * fl(t["jk_hi"])
    lo, hi = (lo, hi) if sign > 0 else (-hi, -lo)
    return "%s [%s, %s]" % (sgn(d), sgn(lo), sgn(hi)), pfmt(fl(t["p"])) + ("$^\\dagger$" if rej else "")


# =========================================================================== Tab. 1
def t_main():
    # Holm over the five backbones, separately for each method compared with the re-run
    fam = {}
    for ref in ("hover", "top1_whole", "vanilla"):
        ps = {b: fl(test(b, ref, "glide")["p"]) for b in BACKBONES if test(b, ref, "glide")}
        fam[ref] = holm(ps)
    out = []
    for i, b in enumerate(BACKBONES):
        rows = [("Vanilla", "vanilla"), ("\\glide (re-run)", "glide"),
                ("\\textsf{H} + top-1, whole clip", "top1_whole"),
                ("\\textbf{\\hover} (%s)" % MAIN_MODE[b], "hover")]
        best = max(fl(meth(b, m)["f1_iou"]) for _, m in rows)
        best = max(best, GLIDE_PUB[b][3] / 100)
        for j, (name, m) in enumerate(rows):
            r = meth(b, m)
            P, R_, F1, FI = (100 * fl(r[k]) for k in ("precision", "recall", "f1", "f1_iou"))
            cells = ["%d" % int(fl(r["num_pred_bugs"])), f2(P), f2(R_), f2(F1), "%.3f" % fl(r["iou_r"]),
                     ("\\textbf{%s}" % f2(FI)) if abs(FI / 100 - best) < 1e-9 else f2(FI)]
            if m == "glide":
                cells += ["", ""]
            else:
                cells += list(dcell(test(b, m, "glide"), 1.0, fam[m].get(b, False)))
            lead = ("\\multirow{5}{*}{%s}" % NICE[b]) if j == 0 else ""
            out.append(lead + " & " + name + " & " + " & ".join(cells) + " \\\\")
        P, R_, F1, FI = GLIDE_PUB[b]
        g = ["--", f2(P), f2(R_), f2(F1), "%.3f" % (FI / F1), f2(FI), "", ""]
        out.append(" & \\color{gray}\\glide (published) & " + " & ".join("\\color{gray}" + c if c else c for c in g) + " \\\\")
        if i < len(BACKBONES) - 1:
            out.append("\\midrule")
    write("t1_main", "\n".join(out))


# ============================================================ Tab. robustness (main text)
def t_robust():
    """HOVER minus re-run under the evaluator variants, clip-level detection, definition test."""
    def cell(t, rej=None):
        if t is None:
            return "--"
        d = 100 * fl(t["delta"])
        p = fl(t["p"])
        star = "$^\\dagger$" if (rej if rej is not None else p < 0.05) else ""
        return "%s%s" % (sgn(d), star)

    lines = []
    for label, rule, rows in (("released evaluator (rating matching)", "rating", None),
                              ("rating $\\times$ IoU matching", "rxiou", None),
                              ("second judge (Qwen2.5-72B)", "rating", TESTS2 if TESTS2 else [])):
        ps = {b: fl(test(b, "hover", "glide", rule, rows)["p"]) for b in BACKBONES if test(b, "hover", "glide", rule, rows)}
        rej = holm(ps)
        lines.append(label + " & " + " & ".join(cell(test(b, "hover", "glide", rule, rows), rej.get(b)) for b in BACKBONES) + " \\\\")
    if all(GCT.values()):
        for label, j in (("tracker-clean re-run$^\\ddagger$", ""), ("\\quad with the second judge", "_j2")):
            ps = {b: fl(clean_test(b, "hover", j)["p"]) for b in BACKBONES}
            rej = holm(ps)
            lines.append(label + " & " + " & ".join(cell(clean_test(b, "hover", j), rej[b]) for b in BACKBONES) + " \\\\")
    lines.append("\\midrule")
    lines.append("\\multicolumn{6}{@{}l}{\\emph{\\hover minus \\textsf{H} + top-1, whole clip}} \\\\")
    for label, rule, rows in (("released evaluator", "rating", None), ("rating $\\times$ IoU matching", "rxiou", None),
                              ("second judge", "rating", TESTS2 if TESTS2 else [])):
        ps = {b: fl(test(b, "hover", "top1_whole", rule, rows)["p"]) for b in BACKBONES if test(b, "hover", "top1_whole", rule, rows)}
        rej = holm(ps)   # Holm over the five backbones, as in the first block
        lines.append(label + " & " + " & ".join(cell(test(b, "hover", "top1_whole", rule, rows), rej.get(b)) for b in BACKBONES) + " \\\\")
    lines.append("\\midrule")
    lines.append("\\multicolumn{6}{@{}l}{\\emph{Glitch-free clips (76): share with a report / clip-level AUROC}} \\\\")
    for label, m in (("\\hover", "hover_selector_umax"), ("\\glide (re-run)", "glide")):
        cells = []
        for b in BACKBONES:
            r = next((x for x in DET if x["backbone"] == b and x["method"] == m), None)
            cells.append("--" if r is None else "%d\\%% / %.2f" % (round(100 * fl(r["fpr_clean"])), fl(r["auroc"])))
        lines.append(label + " & " + " & ".join(cells) + " \\\\")
    write("t_robust", "\n".join(lines))


def clean_test(b, ref, j=""):
    """ref minus the tracker-clean GliDe re-run: the new re-run where one exists, else the main re-run."""
    if b in CLEAN_BB:
        t = next((r for r in GCT[(b, j)] if r["ref"] == ref and r["var"] == "glide_clean"), None)
        return None if t is None else {"delta": t["delta_ref_minus"], "p": t["p"], "lo": t["ci_lo"], "hi": t["ci_hi"]}
    return test(b, ref, "glide", "rating", TESTS2 if j else None)


# ======================================================= Supp.: detection on glitch-free clips
def t_detection_full():
    names = [("hover_selector_umax", "\\hover: max.\\ predicted utility $\\hat u$"),
             ("hover_support_max", "\\hover: max.\\ support"),
             ("hover_generic_detector_z", "\\hover: generic detector"),
             ("hover_description_found", "\\hover: a window reports a glitch"),
             ("glide", "\\glide (re-run): \\#reports"), ("vanilla", "Vanilla: \\#reports")]
    out = []
    for m, label in names:
        cells = []
        for b in BACKBONES:
            r = next((x for x in DET if x["backbone"] == b and x["method"] == m), None)
            if r is None:
                cells.append("--")
                continue
            lo, hi = fl(r["auroc_lo"]), fl(r["auroc_hi"])
            ci = "" if lo != lo else " [%.2f, %.2f]" % (lo, hi)
            cells.append("%d\\%% / %.2f%s" % (round(100 * fl(r["fpr_clean"])), fl(r["auroc"]), ci))
        out.append(label + " & " + " & ".join(cells) + " \\\\")
    write("s_detection", "\n".join(out))


# ===================================================== Supp.: rating x IoU matching, all methods
def t_rxiou_full():
    ms = [("hover", "\\hover"), ("hover_whole", "\\hover, whole clip"), ("top1_whole", "\\textsf{H} + top-1, whole clip"),
          ("glide", "\\glide (re-run)"), ("glide_whole", "\\glide, whole clip"), ("vanilla", "Vanilla"),
          ("const_generic", "Fixed: generic floating object"), ("const_dev_tfidf", "Fixed: TF-IDF dev.\\ medoid"),
          ("const_dev_medoid", "Fixed: judge-selected dev.\\ medoid")]
    out = []
    for m, label in ms:
        cells = []
        for b in BACKBONES:
            a, x = meth(b, m, "rating"), meth(b, m, "rxiou")
            cells.append("--" if a is None or x is None else "%s / %s" % (f2(100 * fl(a["f1_iou"])), f2(100 * fl(x["f1_iou"]))))
        out.append(label + " & " + " & ".join(cells) + " \\\\")
    write("s_rxiou", "\n".join(out))


# ===================================================== Supp.: short glitches
def t_subset():
    out = []
    for thr in ("0.5", "0.3"):
        for rule, rl in (("rating", "rating"), ("rxiou", "r$\\times$IoU")):
            rows = [r for r in SUB if r["cover_lt"] == thr and r["rule"] == rule]
            if not rows:
                continue
            n = {b: next((r["n_clips"] for r in rows if r["backbone"] == b), "--") for b in BACKBONES}
            hv = {b: next((r for r in rows if r["backbone"] == b), None) for b in BACKBONES}
            out.append("\\multicolumn{6}{@{}l}{\\emph{coverage $<$ %s, %s matching (clips: %s)}} \\\\" % (
                thr, rl, ", ".join(str(n[b]) for b in BACKBONES)))
            out.append("\\hover & " + " & ".join("--" if hv[b] is None else f2(100 * fl(hv[b]["f1_iou_hover"])) for b in BACKBONES) + " \\\\")
            for m, label in (("hover_whole", "$-$ whole-clip spans"), ("top1_whole", "$-$ \\textsf{H} + top-1, whole"),
                             ("glide", "$-$ \\glide (re-run)")):
                cells = []
                for b in BACKBONES:
                    r = next((x for x in rows if x["backbone"] == b and x["method"] == m), None)
                    cells.append("--" if r is None else sgn(100 * fl(r["delta"])) + ("$^\\ast$" if fl(r["p"]) < 0.05 else ""))
                out.append(label + " & " + " & ".join(cells) + " \\\\")
    write("s_subset", "\n".join(out))


TRACK = rd("glide_tracker_counts.csv")
TIMING = rd("v2_timing_per_video.csv")
OLD_TIMING = os.path.join(DATA, "timing", "all_backbones_timing_per_video.csv")
OLD_T = list(csv.DictReader(open(OLD_TIMING))) if os.path.exists(OLD_TIMING) else []
NEW_BB = ["qwen3-vl-8b", "qwen2.5-vl-32b"]
NEW_NICE = {"qwen3-vl-8b": "Qwen3-VL-8B", "qwen2.5-vl-32b": "Qwen2.5-VL-32B (AWQ)"}


# ===================================================== Supp.: GliDe's SAM 3 tracker
def t_tracker():
    out = []
    for r in TRACK:
        n = int(r["tracking_calls"])
        sh = lambda k: "%d (%d\\%%)" % (int(r[k]), round(100 * int(r[k]) / n)) if n else "--"
        name = r["run"].replace("qwen2.5-vl-3b (no SAM 3)", "Qwen2.5-VL-3B, no SAM~3")
        name = NICE.get(name, name)
        out.append(" & ".join([name, str(n), sh("success"), sh("no_match"), sh("oom"),
                               sh("frame_loading"), sh("not_initialised")]) + " \\\\")
    for b in CLEAN_BB:
        r = GC[(b, "")].get("glide_clean")
        if r:
            n = int(r["tracking_calls"])
            sh = lambda k: "%d (%d\\%%)" % (int(r[k]), round(100 * int(r[k]) / n))
            out.append(" & ".join([NICE[b] + ", clean re-run", str(n), sh("success"), sh("no_match"), sh("oom"),
                                   sh("frame_loading"), sh("not_initialised")]) + " \\\\")
    write("s_tracker", "\n".join(out))


def _full(b, sub, m):
    return next((r for r in FULL if r["backbone"] == b and r["subset"] == sub and r["method"] == m), None)


def t_full():
    """Supp.: core and vanilla on all 5,238 clips, on the 96 unused games and on the 24 games of our splits."""
    if not FULL:
        return
    L = []
    for b in BACKBONES:
        cells = [NICE[b]]
        for sub in ("all", "unused_96_games", "our_24_games"):
            c, v = _full(b, sub, "core"), _full(b, sub, "vanilla")
            cells.append("%s / %s" % (f2(100 * fl(c["f1_iou"])), f2(100 * fl(v["f1_iou"]))))
        c = _full(b, "all", "core")
        cells.append("%s / %s / %s" % (f2(100 * fl(c["precision"])), f2(100 * fl(c["recall"])), f2(fl(c["iou_r"]))))
        t = next(r for r in FULLT if r["backbone"] == b and r["subset"] == "all")
        cells.append("%s [%s, %s], %s" % (sgn(100 * fl(t["delta_ref_minus"])), sgn(100 * fl(t["ci_lo"])), sgn(100 * fl(t["ci_hi"])), pfmt(fl(t["p"]))))
        L.append(" & ".join(cells) + " \\\\")
    write("s_full", "\n".join(L))


def budget_rows():
    """Per backbone: mean VLM calls, prompt and generated tokens per clip on the 100 timing clips,
    for the GliDe re-run (old per-clip log) and the core (re-timing); counts do not depend on the session."""
    res = {}
    for b in BACKBONES:
        g = [r for r in OLD_T if r["backbone"] == b and r["method"] == "glide"]
        c = [r for r in TIMING if r["backbone"] == b and r["method"] == "h_top1"]
        if not g or not c:
            continue
        mean = lambda rs, k: sum(fl(r[k]) for r in rs) / len(rs)
        res[b] = {m: {k: mean(rs, k) for k in ("model_calls", "prompt_tokens", "completion_tokens")}
                  for m, rs in (("glide", g), ("core", c))}
    return res


def t_v4():
    """Supp.: per-game wins against the re-run, clips with one / several glitches, and the inference budget."""
    if not (V4M and V4G):
        return
    B = budget_rows()
    L = []
    for b in BACKBONES:
        gs = [r for r in V4G if r["backbone"] == b]
        sub = {r["subset"]: r for r in V4M if r["backbone"] == b}
        cells = [NICE[b], "%d / %d" % (sum(fl(r["core_minus_glide"]) > 0 for r in gs), len(gs)),
                 "%d / %d" % (sum(fl(r["hover_minus_glide"]) > 0 for r in gs), len(gs))]
        for s in ("gt1", "gt2plus"):
            r = sub[s]
            cells.append(" / ".join(f2(100 * fl(r[m + "_f1_iou"])) for m in ("core", "hover", "glide")))
        x = B.get(b)
        cells += ["%.0f / %.0f" % (x["glide"]["model_calls"], x["core"]["model_calls"]),
                  "%.0f / %.0f" % (x["glide"]["prompt_tokens"] / 1e3, x["core"]["prompt_tokens"] / 1e3),
                  "%.1f / %.1f" % (x["glide"]["completion_tokens"] / 1e3, x["core"]["completion_tokens"] / 1e3)] if x else ["--"] * 3
        L.append(" & ".join(cells) + " \\\\")
    write("s_v4", "\n".join(L))


def t_splitstats():
    """Supp.: are the 24 games of our splits representative of the 96 others?"""
    if not V4SPLIT:
        return
    lab = {"dev_12_games": "development (12 games)", "test_12_games": "test (12 games)",
           "unused_96_games": "unused (96 games)", "all": "all (120 games)"}
    L = []
    for r in V4SPLIT:
        L.append(" & ".join([lab[r["group"]], "{:,}".format(int(r["n_clips"])).replace(",", "{,}"),
                             "%.1f" % fl(r["mean_duration_s"]), "%.1f" % (100 * fl(r["glitch_free_share"])),
                             "%.1f" % (100 * fl(r["multi_share"])), "%.2f" % fl(r["glitches_per_clip"]),
                             "%.2f" % fl(r["mean_coverage"]), "%.1f" % (100 * fl(r["short_share_lt50"])),
                             r["top_genres"].replace("%", "\\%")]) + " \\\\")
        if r["group"] == "unused_96_games":
            L.append("\\midrule")
    write("s_splitstats", "\n".join(L))


def _tp(b, m):
    return next(r for r in V4TP if r["backbone"] == b and r["method"] == m)


def t_time_paired():
    """Supp.: vanilla, GliDe, the core and HOVER timed back to back on one server (same session)."""
    if not V4TP:
        return
    ci = lambda r: "%.2f [%.2f, %.2f]" % (fl(r["ratio"]), fl(r["ratio_lo"]), fl(r["ratio_hi"]))
    L = []
    for b in BACKBONES:
        c = [NICE[b], "%.1f" % fl(_tp(b, "vanilla")["mean_s"])]
        for m in ("glide", "core", "hover"):
            r = _tp(b, m)
            c += ["%.1f" % fl(r["mean_s"]), "%.2f" % fl(r["rtf"])]
        c += [ci(_tp(b, "core/glide")), ci(_tp(b, "hover/glide")),
              " / ".join("%.2f" % fl(_tp(b, m)["vs_first"]) for m in ("glide", "core", "hover"))]
        L.append(" & ".join(c) + " \\\\")
    write("s_time_paired", "\n".join(L))


def t_glide_clean():
    """Supp.: the tracker-clean re-runs against the first re-run, HOVER and the core, under both judges."""
    if not all(GC.values()):
        return
    L = []
    for b in CLEAN_BB:
        for j, jn in (("", "Llama-3.1-8B"), ("_j2", "Qwen2.5-72B")):
            m, T = GC[(b, j)], GCT[(b, j)]
            t = lambda ref, var: next(r for r in T if r["ref"] == ref and r["var"] == var)
            dc = lambda x: "%s [%s, %s], %s" % (sgn(100 * fl(x["delta_ref_minus"])), sgn(100 * fl(x["ci_lo"])),
                                                 sgn(100 * fl(x["ci_hi"])), pfmt(fl(x["p"])))
            L.append(" & ".join([NICE[b] if not j else "", jn, f2(100 * fl(m["glide"]["f1_iou"])),
                                 "%s (%s)" % (f2(100 * fl(m["glide_clean"]["f1_iou"])), m["glide_clean"]["num_pred_bugs"]),
                                 dc(t("glide_clean", "glide")), dc(t("hover", "glide_clean")), dc(t("top1_whole", "glide_clean"))]) + " \\\\")
        if b != CLEAN_BB[-1]:
            L.append("\\midrule")
    write("s_glide_clean", "\n".join(L))


# ===================================================== Supp.: stage H alone, glitch definitions
def t_definitions():
    out = []
    for b in BACKBONES:
        for d, label in (("orig", "paper's definition"), ("neutral", "neutral definition"), ("glide", "\\glide's categories")):
            r = next((x for x in HON if x["backbone"] == b and x["split"] == "test" and x["definition"] == d), None)
            if r is None or (d != "orig" and not any(x["backbone"] == b and x["definition"] != "orig" for x in HON)):
                continue
            t = next((x for x in HONT if x["backbone"] == b and x["tag"] == "definition" and x["var"] == "top1_whole_" + d), None)
            dd = "" if t is None else "%s [%s, %s] & %s" % (sgn(100 * fl(t["delta_ref_minus"]) * -1),
                                                            sgn(-100 * fl(t["ci_hi"])), sgn(-100 * fl(t["ci_lo"])), pfmt(fl(t["p"])))
            out.append(" & ".join([NICE[b] if d == "orig" else "", label, "%d\\%%" % round(100 * fl(r["forced_share"])),
                                   f2(fl(r["mean_score"])), f2(100 * fl(r["f1_iou"]))]) + " & " + (dd or "& ") + " \\\\")
    write("s_definitions", "\n".join(out))


# ===================================================== main: two further backbones
def t_newbb():
    out = []
    for b in NEW_BB:
        rows = {r["method"]: r for r in NEWB if r["backbone"] == b}
        if not rows:
            continue
        t = {r["var"]: r for r in NEWBT if r["backbone"] == b}
        cell = lambda m: f2(100 * fl(rows[m]["f1_iou"])) if m in rows else "--"
        dv = t.get("vanilla")
        dt = t.get("top1_whole")
        out.append(" & ".join([NEW_NICE[b], "%s" % rows["hover"]["mode"], cell("vanilla"), cell("top1_whole"),
                               cell("hover"), "%d" % int(fl(rows["hover"]["num_pred_bugs"])),
                               ("%s, %s" % (sgn(100 * fl(dv["delta_ref_minus"])), pfmt(fl(dv["p"])))) if dv else "--",
                               ("%s, %s" % (sgn(100 * fl(dt["delta_ref_minus"])), pfmt(fl(dt["p"])))) if dt else "--"]) + " \\\\")
    write("t_newbb", "\n".join(out))


# ===================================================== inference time (re-timed)
def _boot_ratio(pairs, B=2000, seed=0):
    """Total-time ratio sum(a)/sum(b) over clips paired by vid; game-cluster bootstrap, t(G-1) SE interval."""
    import random
    from statistics import stdev
    games = sorted({g for g, _, _ in pairs})
    by = {g: [(a, b) for gg, a, b in pairs if gg == g] for g in games}
    tot = sum(a for _, a, _ in pairs) / sum(b for _, _, b in pairs)
    rng = random.Random(seed)
    vals = []
    for _ in range(B):
        take = [x for g in (rng.choice(games) for _ in games) for x in by[g]]
        vals.append(sum(a for a, _ in take) / sum(b for _, b in take))
    G = len(games)
    lv = [math.log(v) for v in vals]
    se = stdev(lv) * math.sqrt(G / (G - 1))
    q = {11: 2.201, 10: 2.228}.get(G - 1, 2.2)
    return tot, math.exp(math.log(tot) - q * se), math.exp(math.log(tot) + q * se)


def timing_rows():
    """Per backbone: mean s/clip, RTF, total-time ratio vs GliDe (old per-clip log) with intervals."""
    res = {}
    for b in BACKBONES:
        new = {(r["method"], r["vid"]): r for r in TIMING if r["backbone"] == b}
        old = {(r["method"], r["vid"]): r for r in OLD_T if r["backbone"] == b}
        out = {}
        for m in ("hover", "h_top1"):
            vids = [v for (mm, v) in new if mm == m]
            if not vids:
                continue
            w = [fl(new[(m, v)]["wall_s"]) for v in vids]
            dur = [fl(new[(m, v)]["duration"]) for v in vids]
            calls = [fl(new[(m, v)]["model_calls"]) for v in vids]
            pairs = [(new[(m, v)]["game"], fl(new[(m, v)]["wall_s"]), fl(old[("glide", v)]["wall_s"]))
                     for v in vids if ("glide", v) in old]
            ratio = _boot_ratio(pairs) if pairs else (float("nan"),) * 3
            out[m] = {"n": len(vids), "mean_s": sum(w) / len(w), "rtf": sum(w) / sum(dur),
                      "requests": sum(calls) / len(calls), "ratio": ratio, "n_glide": len(pairs)}
        res[b] = out
    return res


def t_time_v2():
    tr = timing_rows()
    out = []
    for b in BACKBONES:
        old = [r for r in OLD_T if r["backbone"] == b]
        g = [fl(r["wall_s"]) for r in old if r["method"] == "glide"]
        gd = [fl(r["duration_s"]) for r in old if r["method"] == "glide"]
        v = [fl(r["wall_s"]) for r in old if r["method"] == "vanilla"]
        vd = [fl(r["duration_s"]) for r in old if r["method"] == "vanilla"]
        cells = [NICE[b],
                 ("%.1f" % (sum(v) / len(v))) if v else "--", ("%.2f" % (sum(v) / sum(vd))) if v else "--",
                 ("%.1f" % (sum(g) / len(g))) if g else "--", ("%.1f" % (sum(g) / sum(gd))) if g else "--"]
        for m in ("h_top1", "hover"):
            x = tr.get(b, {}).get(m)
            cells += ["--", "--"] if x is None else ["%.1f" % x["mean_s"], "%.2f" % x["rtf"]]
        for m in ("h_top1", "hover"):
            x = tr.get(b, {}).get(m)
            cells.append("--" if x is None or x["ratio"][0] != x["ratio"][0] else
                         "%.2f [%.2f, %.2f]" % x["ratio"])
        out.append(" & ".join(cells) + " \\\\")
    write("time_main_v2", "\n".join(out))
    return tr

# ============================================ Supp.: perception beyond a prior, and abstention (round 3)
def _shuf(b, kind):
    """Mean, min and max over seeds of core minus shuffled core (points), and #seeds with p < 0.05."""
    t = [r for r in V3T if r["backbone"] == b and r["ref"] == "top1_whole" and r["var"].startswith("shuffle_" + kind)]
    d = [100 * fl(r["delta_ref_minus"]) for r in t]
    return (sum(d) / len(d), min(d), max(d), sum(fl(r["p"]) < 0.05 for r in t), len(t)) if d else None


def t_v3_controls():
    if not V3C:
        return
    sc = lambda b, m: next((100 * fl(r["f1_iou"]) for r in V3C if r["backbone"] == b and r["method"] == m), float("nan"))
    L = ["\\textsf{H} + top-1 (core) & " + " & ".join(f2(sc(b, "top1_whole")) for b in BACKBONES) + " \\\\"]
    for kind, lab in (("game", "description of another clip, same game"), ("all", "description of another clip, any game")):
        cells = []
        for b in BACKBONES:
            x = _shuf(b, kind)
            cells.append("--" if x is None else "%s [%s, %s] (%d/%d)" % (sgn(x[0]), sgn(x[1]), sgn(x[2]), x[3], x[4]))
        L.append("\\quad core minus %s & " % lab + " & ".join(cells) + " \\\\")
    L.append("\\midrule")
    L.append("core without forced branch & " + " & ".join(f2(sc(b, "top1_abstain")) for b in BACKBONES) + " \\\\")
    cells = []
    for b in BACKBONES:
        t = next((r for r in V3T if r["backbone"] == b and r["ref"] == "top1_whole" and r["var"] == "top1_abstain"), None)
        cells.append("--" if t is None else "%s, %s" % (sgn(100 * fl(t["delta_ref_minus"])), pfmt(fl(t["p"]))))
    L.append("\\quad core minus it, $p$ & " + " & ".join(cells) + " \\\\")
    dd = {r["backbone"]: r for r in V3D}
    L.append("\\quad clips where forced fires & " + " & ".join("%d\\%%" % round(100 * fl(dd[b]["forced_share_all"])) for b in BACKBONES if b in dd) + " \\\\")
    L.append("\\quad glitch-free / glitch clips reported & " + " & ".join(
        "%d\\%% / %d\\%%" % (round(100 * fl(dd[b]["abstain_fpr_clean"])), round(100 * fl(dd[b]["abstain_tpr_glitch"]))) for b in BACKBONES if b in dd) + " \\\\")
    write("s_v3_controls", "\n".join(L))


# ============================================ Supp.: blinded human check of both judges (round 3)
HM_NICE = {"core": "\\textsf{H} + top-1 (core)", "hover": "\\hover", "glide": "\\glide (re-run)",
           "tfidf": "Fixed sentence (TF-IDF medoid)"}
RATERS = (("A", "Annotator A"), ("B", "Annotator B"), ("H", "Human consensus"), ("llama", "Llama-3.1-8B"),
          ("qwen72b", "Qwen2.5-72B"))


def _hag(subset, pair):
    return next((r for r in HAG if r["subset"] == subset and r["pair"] == pair), None)


def _hdiff(m, rater):
    return next((r for r in HME if r["kind"] == "diff" and r["method"] == m and r["rater"] == rater), None)


def t_human():
    if not (HAG and HME and HJU):
        return
    meth = {r["method"]: r for r in HME if r["kind"] == "method"}
    L = []
    for c, lab in RATERS:
        L.append(lab + " & " + " & ".join("%s / %d\\%%" % (f2(fl(meth[m]["mean_" + c])), round(100 * fl(meth[m]["correct_" + c])))
                                     for m in ("core", "hover", "glide", "tfidf")) + " \\\\")
        if c == "H":
            L.append("\\midrule")
    write("s_human_methods", "\n".join(L))
    L = []
    for subset in ("all", "core", "hover", "glide", "tfidf"):
        cells = []
        for pair in ("A_vs_B", "human_vs_llama8b", "human_vs_qwen72b", "llama8b_vs_qwen72b"):
            r = _hag(subset, pair)
            cells.append("%s [%s, %s] / %s" % tuple(f2(fl(r[q])).replace("-", "$-$") for q in ("kappa_w", "kappa_lo", "kappa_hi", "spearman")))
        lab = "All (140)" if subset == "all" else HM_NICE[subset] + " (35)"
        L.append(lab + " & " + " & ".join(cells) + " \\\\")
    write("s_human_agree", "\n".join(L))
    L = []
    for m, lab in (("core-tfidf", "core $-$ fixed sentence"), ("hover-tfidf", "\\hover $-$ fixed sentence"),
                   ("glide-tfidf", "\\glide $-$ fixed sentence"), ("core-glide", "core $-$ \\glide"),
                   ("hover-glide", "\\hover $-$ \\glide"), ("hover-core", "\\hover $-$ core")):
        cells = []
        for c, _ in RATERS:
            r = _hdiff(m, c)
            cells.append("%s (%s)" % (sgn(fl(r["diff"])), pfmt(fl(r["p"]))))
        L.append(lab + " & " + " & ".join(cells) + " \\\\")
    write("s_human_diff", "\n".join(L))
    L = []
    for j, lab in (("llama", "Llama-3.1-8B"), ("qwen72b", "Qwen2.5-72B")):
        rr = {r["method"]: r for r in HJU if r["judge"] == j}
        for key, nm in (("judge_correct", "rated correct"), ("precision_vs_human", "of these, correct for the humans")):
            L.append("%s: %s & " % (lab, nm) + " & ".join("%d\\%%" % round(100 * fl(rr[m][key])) for m in ("all", "core", "hover", "glide", "tfidf")) + " \\\\")
        L.append("%s: $\\kappa_w$ with A / with B & " % lab + " & ".join("%s / %s" % (f2(fl(rr[m]["kappa_A"])), f2(fl(rr[m]["kappa_B"]))) for m in ("all", "core", "hover", "glide", "tfidf")) + " \\\\")
    rr = {r["method"]: r for r in HJU if r["judge"] == "llama"}
    L.insert(0, "Humans: rated correct (consensus $\\geq3$) & " + " & ".join("%d\\%%" % round(100 * fl(rr[m]["human_correct"])) for m in ("all", "core", "hover", "glide", "tfidf")) + " \\\\")
    L.insert(1, "Annotator A vs B: $\\kappa_w$ & " + " & ".join(f2(fl(rr[m]["kappa_AB"])) for m in ("all", "core", "hover", "glide", "tfidf")) + " \\\\")
    L.insert(2, "\\midrule")
    L.insert(6, "\\midrule")
    write("s_human_judges", "\n".join(L))


def numbers():
    L = ["%% generated by scripts/make_v2_tables.py"]
    def mac(name, val):
        L.append("\\newcommand{\\%s}{%s}" % (name, val))
    g = lambda m, rule="rating": [100 * fl(test(b, m, "glide", rule)["delta"]) for b in BACKBONES if test(b, m, "glide", rule)]
    for m, nm in (("hover", "Hov"), ("top1_whole", "Top")):
        for rule, rn in (("rating", ""), ("rxiou", "Rx")):
            d = g(m, rule)
            if d:
                mac("gain%s%sMin" % (nm, rn), f2(min(d))); mac("gain%s%sMax" % (nm, rn), f2(max(d)))
    if TESTS2:
        d = [100 * fl(test(b, "hover", "glide", "rating", TESTS2)["delta"]) for b in BACKBONES if test(b, "hover", "glide", "rating", TESTS2)]
        if d:
            mac("gainHovJtwoMin", f2(min(d))); mac("gainHovJtwoMax", f2(max(d)))
    top = [abs(100 * fl(test(b, "hover", "top1_whole")["delta"])) for b in BACKBONES if test(b, "hover", "top1_whole")]
    if top:
        mac("hovTopMaxAbs", f2(max(top)))
    calls = [fl(r["calls_per_clip"]) for r in HON if r["split"] == "test" and r["definition"] == "orig"]
    if calls:
        mac("callsTopMin", "%.1f" % min(calls)); mac("callsTopMax", "%.1f" % max(calls))
    for m, nm in (("hover_selector_umax", "Hov"), ("glide", "Gli")):
        rr = [r for r in DET if r["method"] == m]
        if rr:
            mac("fpr%sMin" % nm, "%d" % round(100 * min(fl(r["fpr_clean"]) for r in rr)))
            mac("fpr%sMax" % nm, "%d" % round(100 * max(fl(r["fpr_clean"]) for r in rr)))
            mac("auc%sMin" % nm, "%.2f" % min(fl(r["auroc"]) for r in rr))
            mac("auc%sMax" % nm, "%.2f" % max(fl(r["auroc"]) for r in rr))
    ns = next((r for r in METH if r["backbone"] == "qwen2.5-vl-3b" and r["method"] == "glide_nosam3" and r["rule"] == "rating"), None)
    if ns:
        mac("glideNoSamQthree", f2(100 * fl(ns["f1_iou"])))
    sq = next((r for r in SUB if r["backbone"] == "qwen2.5-vl-7b" and r["cover_lt"] == "0.5" and r["rule"] == "rating"
               and r["method"] == "hover_whole"), None)
    if sq:
        mac("shortLocQseven", sgn(100 * fl(sq["delta"]))); mac("shortLocQsevenP", "%.3f" % fl(sq["p"]))
        mac("shortN", sq["n_clips"])
    tr = timing_rows()
    rat = [x["ratio"][0] for b in BACKBONES for m, x in tr.get(b, {}).items() if m == "hover"]
    if rat:
        mac("timeSpeedMinVtwo", "%.1f" % (1 / max(rat))); mac("timeSpeedMaxVtwo", "%.1f" % (1 / min(rat)))
    rat = [x["ratio"][0] for b in BACKBONES for m, x in tr.get(b, {}).items() if m == "h_top1"]
    if rat:
        mac("timeSpeedTopMin", "%.1f" % (1 / max(rat))); mac("timeSpeedTopMax", "%.1f" % (1 / min(rat)))
    if V3T:
        for kind, nm in (("game", "Game"), ("all", "All")):
            m = [_shuf(b, kind)[0] for b in BACKBONES if _shuf(b, kind)]
            mac("shuf%sMin" % nm, f2(min(m))); mac("shuf%sMax" % nm, f2(max(m)))
    if FULL:
        for sub, nm in (("all", "All"), ("unused_96_games", "Unused"), ("our_24_games", "Ours")):
            for m, mn in (("core", "Core"), ("vanilla", "Van")):
                v = [100 * fl(_full(b, sub, m)["f1_iou"]) for b in BACKBONES]
                mac("full%s%sMin" % (nm, mn), f2(min(v))); mac("full%s%sMax" % (nm, mn), f2(max(v)))
        d = [100 * fl(r["delta_ref_minus"]) for r in FULLT if r["subset"] == "all"]
        mac("fullDiffMin", f2(min(d))); mac("fullDiffMax", f2(max(d)))
        mac("fullPmax", pfmt(max(fl(r["p"]) for r in FULLT)))
    if all(GCT.values()):
        for ref, nm in (("hover", "Hov"), ("top1_whole", "Top")):
            for j, jn in (("", ""), ("_j2", "Jtwo")):
                d = [100 * fl(clean_test(b, ref, j)["delta"]) for b in BACKBONES]
                mac("cleanGain%s%sMin" % (nm, jn), f2(min(d))); mac("cleanGain%s%sMax" % (nm, jn), f2(max(d)))
                mac("cleanP%s%sQthree" % (nm, jn), pfmt(fl(clean_test("qwen2.5-vl-3b", ref, j)["p"])))
        for b, nm in (("qwen2.5-vl-3b", "Qthree"), ("internvl2.5-8b", "Ieight"), ("ui-tars-1.5-7b", "Ut")):
            t = next(r for r in GCT[(b, "")] if r["ref"] == "glide_clean" and r["var"] == "glide")
            mac("cleanVsFirst%s" % nm, sgn(100 * fl(t["delta_ref_minus"]))); mac("cleanVsFirstP%s" % nm, pfmt(fl(t["p"])))
            mac("cleanScore%s" % nm, f2(100 * fl(GC[(b, "")]["glide_clean"]["f1_iou"])))
    if HAG and HME and HJU:
        for pair, nm in (("A_vs_B", "AB"), ("human_vs_llama8b", "Llama"), ("human_vs_qwen72b", "Qwen")):
            r = _hag("all", pair)
            mac("humKappa%s" % nm, f2(fl(r["kappa_w"])))
            mac("humKappa%sLo" % nm, f2(fl(r["kappa_lo"]))); mac("humKappa%sHi" % nm, f2(fl(r["kappa_hi"])))
            mac("humRho%s" % nm, f2(fl(r["spearman"])))
        mac("humN", _hag("all", "A_vs_B")["n"])
        meth = {r["method"]: r for r in HME if r["kind"] == "method"}
        for m, nm in (("core", "Core"), ("hover", "Hov"), ("glide", "Gli"), ("tfidf", "Fix")):
            for c, cn in (("H", "Hum"), ("llama", "Llama"), ("qwen72b", "Qwen"), ("A", "A"), ("B", "B")):
                mac("hum%sMean%s" % (cn, nm), f2(fl(meth[m]["mean_" + c])))
                mac("hum%sCorr%s" % (cn, nm), "%d" % round(100 * fl(meth[m]["correct_" + c])))
        for m, nm in (("core-tfidf", "CoreFix"), ("hover-tfidf", "HovFix"), ("glide-tfidf", "GliFix"),
                      ("core-glide", "CoreGli"), ("hover-glide", "HovGli"), ("hover-core", "HovCore")):
            for c, cn in (("H", "Hum"), ("A", "A"), ("B", "B"), ("llama", "Llama"), ("qwen72b", "Qwen")):
                r = _hdiff(m, c)
                mac("humD%s%s" % (cn, nm), sgn(fl(r["diff"]))); mac("humP%s%s" % (cn, nm), pfmt(fl(r["p"])))
                if c == "H":
                    mac("humD%s%sLo" % (cn, nm), sgn(fl(r["lo"]))); mac("humD%s%sHi" % (cn, nm), sgn(fl(r["hi"])))
        for j, jn in (("llama", "Llama"), ("qwen72b", "Qwen")):
            rr = {r["method"]: r for r in HJU if r["judge"] == j}
            mac("humJcorr%s" % jn, "%d" % round(100 * fl(rr["all"]["judge_correct"])))
            mac("humPrec%s" % jn, "%d" % round(100 * fl(rr["all"]["precision_vs_human"])))
            mac("humPrec%sFix" % jn, "%d" % round(100 * fl(rr["tfidf"]["precision_vs_human"])))
            mac("humBias%s" % jn, sgn(fl(rr["all"]["mean_bias"])))
            mac("humKappaA%s" % jn, f2(fl(rr["all"]["kappa_A"]))); mac("humKappaB%s" % jn, f2(fl(rr["all"]["kappa_B"])))
        for c in ("A", "B"):   # 35 pairs per method, so the overall share is the mean of the four
            mac("hum%sCorrAll" % c, "%d" % round(100 * sum(fl(meth[m]["correct_" + c]) for m in meth) / len(meth)))
        mac("humJcorrHum", "%d" % round(100 * fl({r["method"]: r for r in HJU if r["judge"] == "llama"}["all"]["human_correct"])))
    if V4M and V4G and V4S:
        st = {r["split"]: r for r in V4S}
        mac("multiN", st["test"]["clips_2plus"]); mac("multiNall", st["all"]["clips_2plus"])
        mac("multiShareAll", "%.1f" % (100 * fl(st["all"]["share_2plus"])))
        mac("oneRepCeilAll", "%.1f" % (100 * fl(st["all"]["recall_ceiling_one_report"])))
        mac("oneRepCeilTest", "%.1f" % (100 * fl(st["test"]["recall_ceiling_one_report"])))
        sub = {(r["backbone"], r["subset"]): r for r in V4M}
        mac("multiCoreWins", "%d" % sum(fl(sub[(b, "gt2plus")]["core_f1_iou"]) > fl(sub[(b, "gt2plus")]["glide_f1_iou"]) for b in BACKBONES))
        mac("singleCoreWins", "%d" % sum(fl(sub[(b, "gt1")]["core_f1_iou"]) > fl(sub[(b, "gt1")]["glide_f1_iou"]) for b in BACKBONES))
        for m, nm in (("core", "Core"), ("hover", "Hov")):
            mac("games%sWins" % nm, "%d" % sum(fl(r[m + "_minus_glide"]) > 0 for r in V4G))
            mac("games%sAllTwelve" % nm, "%d" % sum(all(fl(r[m + "_minus_glide"]) > 0 for r in V4G if r["backbone"] == b) for b in BACKBONES))
        mac("gamesCells", "%d" % len(V4G))
        mac("gamesCoreWinsQthree", "%d" % sum(fl(r["core_minus_glide"]) > 0 for r in V4G if r["backbone"] == "qwen2.5-vl-3b"))
        B = budget_rows()
        for m, nm in (("glide", "Gli"), ("core", "Core")):
            for k, kn, sc, fm in (("model_calls", "Calls", 1, "%.0f"), ("prompt_tokens", "Ptok", 1e3, "%.0f"),
                                  ("completion_tokens", "Ctok", 1e3, "%.1f")):
                v = [B[b][m][k] / sc for b in B]
                mac("budget%s%sMin" % (nm, kn), fm % min(v)); mac("budget%s%sMax" % (nm, kn), fm % max(v))
    if V4TP:
        mac("tpN", "%d" % int(_tp(BACKBONES[0], "glide")["n"]))
        mac("tpNfirst", "%d" % int(_tp(BACKBONES[0], "glide")["n_first"]))
        for m, nm in (("core", "Core"), ("hover", "Hov")):
            r = [fl(_tp(b, m + "/glide")["ratio"]) for b in BACKBONES]
            mac("tp%sRatioMin" % nm, "%.2f" % min(r)); mac("tp%sRatioMax" % nm, "%.2f" % max(r))
            mac("tp%sSpeedMin" % nm, "%.1f" % (1 / max(r))); mac("tp%sSpeedMax" % nm, "%.1f" % (1 / min(r)))
            hi = [fl(_tp(b, m + "/glide")["ratio_hi"]) for b in BACKBONES]
            mac("tp%sRatioHiMax" % nm, "%.2f" % max(hi))
            s_ = [fl(_tp(b, m)["mean_s"]) for b in BACKBONES]
            mac("tp%sSecMin" % nm, "%.1f" % min(s_)); mac("tp%sSecMax" % nm, "%.1f" % max(s_))
        for m, nm in (("glide", "Gli"), ("vanilla", "Van")):
            s_ = [fl(_tp(b, m)["mean_s"]) for b in BACKBONES]
            mac("tp%sSecMin" % nm, "%.1f" % min(s_)); mac("tp%sSecMax" % nm, "%.1f" % max(s_))
        for m, nm in (("glide", "Gli"), ("core", "Core"), ("hover", "Hov")):
            d = [fl(_tp(b, m)["vs_first"]) for b in BACKBONES]
            mac("tpDrift%sMin" % nm, "%.2f" % min(d)); mac("tpDrift%sMax" % nm, "%.2f" % max(d))
    write("v2_numbers", "\n".join(L))


if __name__ == "__main__":
    t_main(); t_robust(); t_detection_full(); t_rxiou_full(); t_subset(); t_tracker()
    t_definitions(); t_newbb(); t_time_v2(); t_v3_controls(); t_human(); t_glide_clean(); t_full(); t_v4(); t_splitstats(); t_time_paired(); numbers()
