# HOVER v10 on UAL-Bench: Mode A (query-conditioned HOVER localisation core)

**Status: FULL RUN (all evaluation items)**

- Mode A: the official query is the HOVER hypothesis; HOVER V (contextually calibrated presence profile) and S (exact segmentation, K = 1) with masked-frame boundary refinement. The open-ended H stage and the U selector are not used, so this is not an evaluation of the full H -> V -> S -> U pipeline.
- Selection rule fixed before any UAL result: tau = 0, lambda = 1e+09, refine = frame; nothing was calibrated on UAL-Bench.
- Metrics: exact port of the official evaluator (Hasnat79/UAL_Bench src/eval/eval_your_results.py).
- R@1 values and onset accuracies are percentages (100 x correct / N). mIoU is a fraction in [0, 1]. mTD is in seconds; TD = |start error| + |end error|; a null prediction counts as IoU 0 and TD = gt end_time (official convention).
- Results are not aggregated across subsets (different domains, sizes and query types). Published UAL-Bench numbers are not included here; compare only with the same subset, metric and protocol, and label them as published.

## UAG-OOPS

N = 1589 evaluation items over 1589 videos.

Model | R@1,0.3 | R@1,0.5 | R@1,0.7 | R@1,TD≤0 | R@1,TD≤1 | R@1,TD≤3 | R@1,TD≤5 | mTD
--- | --- | --- | --- | --- | --- | --- | --- | ---
UI-TARS-1.5-7B | 71.68 | 48.08 | 24.42 | 0.00 | 18.12 | 55.19 | 78.29 | 3.55

Supplementary official metrics (outputs of the official evaluator that are not in the main table):

Model | mIoU | R@1,TD≤7 | Onset acc. ≤1 s | Onset acc. ≤0.25 s
--- | --- | --- | --- | ---
UI-TARS-1.5-7B | 0.484 | 88.61 | 35.18 | 11.20

Diagnostics (NOT official metrics; 95% CIs by video-cluster bootstrap, B = 2000):

Model | null predictions | Yes/No outside top-logprobs (share of calls) | VLM calls/item | 95% CI mIoU | 95% CI R@1,0.5 | 95% CI mTD
--- | --- | --- | --- | --- | --- | ---
UI-TARS-1.5-7B | 0 | 0.0% | 5.6 | [0.471, 0.497] | [45.63, 50.47] | [3.39, 3.72]

Reference, NOT a model: the whole-video span [0, decoded duration] scored by the same evaluator (any localiser should beat it):

Model | R@1,0.3 | R@1,0.5 | R@1,0.7 | R@1,TD≤0 | R@1,TD≤1 | R@1,TD≤3 | R@1,TD≤5 | mTD
--- | --- | --- | --- | --- | --- | --- | --- | ---
Whole video (no model) | 84.64 | 63.75 | 28.95 | 0.00 | 10.89 | 50.66 | 82.57 | 3.49

