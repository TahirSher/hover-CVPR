# HOVER v10 on UAL-Bench: Mode A (query-conditioned HOVER localisation core)

**Status: FULL RUN (all evaluation items)**

- Mode A: the official query is the HOVER hypothesis; HOVER V (contextually calibrated presence profile) and S (exact segmentation, K = 1) with masked-frame boundary refinement. The open-ended H stage and the U selector are not used, so this is not an evaluation of the full H -> V -> S -> U pipeline.
- Selection rule fixed before any UAL result: tau = 0, lambda = 1e+09, refine = frame; nothing was calibrated on UAL-Bench.
- Metrics: exact port of the official evaluator (Hasnat79/UAL_Bench src/eval/eval_your_results.py).
- R@1 values and onset accuracies are percentages (100 x correct / N). mIoU is a fraction in [0, 1]. mTD is in seconds; TD = |start error| + |end error|; a null prediction counts as IoU 0 and TD = gt end_time (official convention).
- Results are not aggregated across subsets (different domains, sizes and query types). Published UAL-Bench numbers are not included here; compare only with the same subset, metric and protocol, and label them as published.

## UAG-FunQA

N = 172 evaluation items over 172 videos.

Every UAG-FunQA query is the same instruction ("Identify the video's funny moment."), so conditioning on it carries no item-specific information.

Model | R@1,0.3 | R@1,0.5 | R@1,0.7 | R@1,TD≤0 | R@1,TD≤1 | R@1,TD≤3 | R@1,TD≤5 | mTD
--- | --- | --- | --- | --- | --- | --- | --- | ---
Qwen2.5-VL-7B-Instruct | 81.40 | 56.98 | 38.37 | 0.00 | 33.72 | 63.37 | 85.47 | 2.81

Supplementary official metrics (outputs of the official evaluator that are not in the main table):

Model | mIoU | R@1,TD≤7 | Onset acc. ≤1 s | Onset acc. ≤0.25 s
--- | --- | --- | --- | ---
Qwen2.5-VL-7B-Instruct | 0.561 | 94.19 | 55.23 | 33.14

Diagnostics (NOT official metrics; 95% CIs by video-cluster bootstrap, B = 2000):

Model | null predictions | Yes/No outside top-logprobs (share of calls) | VLM calls/item | 95% CI mIoU | 95% CI R@1,0.5 | 95% CI mTD
--- | --- | --- | --- | --- | --- | ---
Qwen2.5-VL-7B-Instruct | 0 | 0.0% | 5.1 | [0.520, 0.604] | [50.00, 64.53] | [2.37, 3.27]

Reference, NOT a model: the whole-video span [0, decoded duration] scored by the same evaluator (any localiser should beat it):

Model | R@1,0.3 | R@1,0.5 | R@1,0.7 | R@1,TD≤0 | R@1,TD≤1 | R@1,TD≤3 | R@1,TD≤5 | mTD
--- | --- | --- | --- | --- | --- | --- | --- | ---
Whole video (no model) | 80.81 | 58.14 | 41.28 | 0.00 | 33.14 | 62.79 | 80.81 | 2.94

