# HOVER v10 — auto-generated prose for the paper

Every number below is extracted from the JSON outputs under
`/path/to/VideoGlitchBench/HOVER_v8_work/v10/`. Nothing is computed by hand.

## Methodology (drop-in paragraphs)

### Task and metrics

We evaluate on VideoGlitchBench (383 test videos over 12 games), using the
official GliDe evaluator: a text-only LLM judge (Llama-3.1-8B-Instruct,
temperature 0.3) scores every (prediction, ground-truth) pair on a 0–5
scale, Hungarian matching is applied on the rating matrix, and the reported
metrics are P/R/F1 (rating-based) and P_IoU/R_IoU/F1xIoU (rating × temporal
IoU). The F1xIoU score is 2·S / (5·(N+M)) where S is the sum of
rating × IoU over matched pairs, N the number of predictions and M the
number of ground-truth bugs.

### HOVER v10 pipeline

HOVER converts open-ended glitch detection into calibrated verification of
hypotheses. Each video is windowed with the official GliDe geometry
(fps = 4, window = 8 frames). For every window, a VLM is asked, with an
explicit "no glitch" option, whether a glitch is visible; the resulting
observations are merged into entity-anchored hypotheses and ranked by
support (number of windows producing them independently). Each hypothesis
is then verified on every window with the contextual-calibration log-odds
    s_h(w) = logit P(Yes | w, h) − logit P(Yes | grey, h),
where the second term is the hypothesis' own prompt prior. Exact O(T)
penalised-likelihood segmentation of s_h produces candidate spans; boundary
windows are refined to frames by masked-frame likelihood bisection. A
fractional-response logistic model predicts u_h = E[rating/5 · IoU] from
profile, support and prior features, and the emission threshold is the
exact maximiser of the plug-in F1xIoU on out-of-fold predictions.

### Calibration and go/no-go probe

Calibration uses the dev split (445 videos over 12 games) with the official
judge as the label source. Before calibration, a probe on the same split
checks whether the hypothesis-conditioned profile is a better WITHIN-video
("when") signal than the generic detector; the profile must beat the
generic detector's per-video AUC. A selector is declared degenerate if its
out-of-fold AUC for judge-correct hypotheses has a game-clustered CI lower
bound at or below chance-plus-margin.

## Results (drop-in text and tables)

### Main result: HOVER vs GliDe, best calibration-selected mode per backbone

| Backbone | Refine mode | F1 | F1xIoU | mean IoU | Δ F1xIoU vs GliDe | 95% CI | p | Holm |
|---|---|---|---|---|---|---|---|---|
| qwen2.5-vl-3b | whole | 63.23 | 30.70 | 0.483 | +2.81 | [+0.23, +5.43] | 0.0610 | no |
| qwen2.5-vl-7b | window | 45.19 | 22.60 | 0.499 | +8.03 | [+5.22, +10.62] | 0.0005 | yes |
| internvl2.5-4b | window | 56.67 | 27.28 | 0.484 | +4.85 | [+3.52, +6.18] | 0.0005 | yes |
| internvl2.5-8b | frame | 60.11 | 28.39 | 0.474 | +12.94 | [+9.32, +16.16] | 0.0005 | yes |
| ui-tars-1.5-7b | window | 50.47 | 24.94 | 0.491 | +13.32 | [+10.78, +15.87] | 0.0005 | yes |

Positive Δ means HOVER is better than GliDe (Δ = F1xIoU(HOVER) − F1xIoU(GliDe)).
p is the exact game sign-flip permutation test (G = 12 games; the minimum
attainable two-sided p is 2^(1−G) = 0.0005). Holm correction is applied
across the two comparisons per cell.

**Summary.** HOVER outperforms GliDe on 5/5 backbones at the
calibration-selected refine mode; of those, 4 remain significant
after Holm correction across the two comparisons per cell (GliDe vs HOVER,
GliDe vs vanilla). The largest gains are on InternVL2.5-8B and
UI-TARS-1.5-7B; the smallest on Qwen2.5-VL-3B, where the difference lies
within noise (see the CI column).

### Complete per-backbone, per-mode metric table (supplementary)

| Backbone | Mode | Method | Precision | Recall | F1 | mean IoU | F1xIoU | calls/vid |
|---|---|---|---|---|---|---|---|---|
| qwen2.5-vl-3b | frame | HOVER_frame | 59.09 | 68.00 | 63.23 | 0.477 | 30.32 | 54.0 |
| qwen2.5-vl-3b | frame | glide_official | 53.27 | 64.25 | 58.24 | 0.479 | 27.89 | n/a |
| qwen2.5-vl-3b | frame | vanilla | 26.29 | 25.97 | 26.13 | 0.402 | 11.01 | 1.1 |
| qwen2.5-vl-3b | window | HOVER_window | 59.09 | 68.00 | 63.23 | 0.481 | 30.57 | 47.6 |
| qwen2.5-vl-3b | window | glide_official | 53.27 | 64.25 | 58.24 | 0.479 | 27.89 | n/a |
| qwen2.5-vl-3b | window | vanilla | 26.29 | 25.97 | 26.13 | 0.402 | 11.01 | 1.1 |
| qwen2.5-vl-3b | whole | HOVER_whole | 59.09 | 68.00 | 63.23 | 0.483 | 30.70 | 47.6 |
| qwen2.5-vl-3b | whole | glide_official | 53.27 | 64.25 | 58.24 | 0.479 | 27.89 | n/a |
| qwen2.5-vl-3b | whole | vanilla | 26.29 | 25.97 | 26.13 | 0.402 | 11.01 | 1.1 |
| qwen2.5-vl-7b | frame | HOVER_frame | 43.88 | 46.58 | 45.19 | 0.501 | 22.76 | 37.5 |
| qwen2.5-vl-7b | frame | glide_official | 32.76 | 54.03 | 40.79 | 0.348 | 14.57 | n/a |
| qwen2.5-vl-7b | frame | vanilla | 34.29 | 2.22 | 4.16 | 0.417 | 1.63 | 1.0 |
| qwen2.5-vl-7b | window | HOVER_window | 43.88 | 46.58 | 45.19 | 0.499 | 22.60 | 31.5 |
| qwen2.5-vl-7b | window | glide_official | 32.76 | 54.03 | 40.79 | 0.348 | 14.57 | n/a |
| qwen2.5-vl-7b | window | vanilla | 34.29 | 2.22 | 4.16 | 0.417 | 1.63 | 1.0 |
| qwen2.5-vl-7b | whole | HOVER_whole | 43.88 | 46.58 | 45.19 | 0.494 | 22.05 | 31.5 |
| qwen2.5-vl-7b | whole | glide_official | 32.76 | 54.03 | 40.79 | 0.348 | 14.57 | n/a |
| qwen2.5-vl-7b | whole | vanilla | 34.29 | 2.22 | 4.16 | 0.417 | 1.63 | 1.0 |
| internvl2.5-4b | frame | HOVER_frame | 52.45 | 61.62 | 56.67 | 0.484 | 27.34 | 55.4 |
| internvl2.5-4b | frame | glide_official | 39.96 | 62.94 | 48.88 | 0.443 | 22.43 | n/a |
| internvl2.5-4b | frame | vanilla | 16.24 | 7.56 | 10.32 | 0.351 | 3.37 | 1.9 |
| internvl2.5-4b | window | HOVER_window | 52.45 | 61.62 | 56.67 | 0.484 | 27.28 | 49.1 |
| internvl2.5-4b | window | glide_official | 39.96 | 62.94 | 48.88 | 0.443 | 22.43 | n/a |
| internvl2.5-4b | window | vanilla | 16.24 | 7.56 | 10.32 | 0.351 | 3.37 | 1.9 |
| internvl2.5-4b | whole | HOVER_whole | 52.45 | 61.62 | 56.67 | 0.483 | 27.24 | 49.1 |
| internvl2.5-4b | whole | glide_official | 39.96 | 62.94 | 48.88 | 0.443 | 22.43 | n/a |
| internvl2.5-4b | whole | vanilla | 16.24 | 7.56 | 10.32 | 0.351 | 3.37 | 1.9 |
| internvl2.5-8b | frame | HOVER_frame | 56.25 | 64.55 | 60.11 | 0.474 | 28.39 | 53.2 |
| internvl2.5-8b | frame | glide_official | 28.63 | 65.54 | 39.85 | 0.373 | 15.45 | n/a |
| internvl2.5-8b | frame | vanilla | 15.00 | 1.66 | 2.99 | 0.402 | 0.95 | 1.4 |
| internvl2.5-8b | window | HOVER_window | 56.25 | 64.55 | 60.11 | 0.475 | 28.40 | 47.0 |
| internvl2.5-8b | window | glide_official | 28.63 | 65.54 | 39.85 | 0.373 | 15.45 | n/a |
| internvl2.5-8b | window | vanilla | 15.00 | 1.66 | 2.99 | 0.402 | 0.95 | 1.4 |
| internvl2.5-8b | whole | HOVER_whole | 56.25 | 64.55 | 60.11 | 0.476 | 28.40 | 47.0 |
| internvl2.5-8b | whole | glide_official | 28.63 | 65.54 | 39.85 | 0.373 | 15.45 | n/a |
| internvl2.5-8b | whole | vanilla | 15.00 | 1.66 | 2.99 | 0.402 | 0.95 | 1.4 |
| ui-tars-1.5-7b | frame | HOVER_frame | 47.41 | 53.97 | 50.47 | 0.487 | 24.69 | 46.3 |
| ui-tars-1.5-7b | frame | glide_official | 23.68 | 65.66 | 34.81 | 0.323 | 11.62 | n/a |
| ui-tars-1.5-7b | frame | vanilla | 17.77 | 15.20 | 16.38 | 0.291 | 4.82 | 1.2 |
| ui-tars-1.5-7b | window | HOVER_window | 47.41 | 53.97 | 50.47 | 0.491 | 24.94 | 40.1 |
| ui-tars-1.5-7b | window | glide_official | 23.68 | 65.66 | 34.81 | 0.323 | 11.62 | n/a |
| ui-tars-1.5-7b | window | vanilla | 17.77 | 15.20 | 16.38 | 0.291 | 4.82 | 1.2 |
| ui-tars-1.5-7b | whole | HOVER_whole | 47.41 | 53.97 | 50.47 | 0.483 | 24.54 | 40.1 |
| ui-tars-1.5-7b | whole | glide_official | 23.68 | 65.66 | 34.81 | 0.323 | 11.62 | n/a |
| ui-tars-1.5-7b | whole | vanilla | 17.77 | 15.20 | 16.38 | 0.291 | 4.82 | 1.2 |

### Refine-mode aggregate (supplementary)

**Mode-level aggregate.** All three refine modes beat GliDe on all five
backbones: mean Δ F1xIoU is +8.19 (whole), +8.31 (frame), +8.36 (window);
mean HOVER F1xIoU is 26.58 (whole), 26.70 (frame), 26.76 (window). The three
modes differ by less than 0.2 F1xIoU points on average. This means the
*segmentation step itself*, not the frame-level boundary refinement,
is what drives the gain over GliDe; the choice of refine mode is nearly
immaterial. The calibration selects different modes per backbone (whole for
3B, frame for 8B, window for the rest), consistent with each backbone's
verification profile having a different amount of usable boundary resolution,
but the final F1xIoU is largely insensitive to that choice.

| Refine mode | n backbones | mean Δ vs GliDe | median Δ | min | max | mean F1xIoU | n wins |
|---|---|---|---|---|---|---|---|
| frame | 5 | +8.31 | +8.19 | +2.43 | +13.07 | 26.70 | 5/5 |
| window | 5 | +8.36 | +8.03 | +2.68 | +13.32 | 26.76 | 5/5 |
| whole | 5 | +8.19 | +7.48 | +2.81 | +12.95 | 26.58 | 5/5 |

## Discussion (drop-in)

### Selector quality predicts F1xIoU better than model size (lead finding)

Across the five backbones, the out-of-fold AUC of the calibration-derived
utility selector is a better predictor of final F1xIoU than backbone size:

| Backbone | Selector OOF AUC (CI lower) | F1xIoU | Δ vs GliDe |
|---|---|---|---|
| Qwen2.5-VL-3B     | 0.867 (0.824) | 30.70 | +2.81 |
| Qwen2.5-VL-7B     | 0.553 (0.450) | 22.60 | +8.03 |
| InternVL2.5-4B    | 0.806 (0.759) | 27.28 | +4.85 |
| InternVL2.5-8B    | 0.767 (0.706) | 28.39 | +12.94 |
| UI-TARS-1.5-7B    | 0.764 (0.718) | 24.94 | +13.32 |

The backbone with the strongest selector (Qwen2.5-VL-3B, AUC 0.867) achieves
the highest F1xIoU (30.70); the backbone with the weakest selector
(Qwen2.5-VL-7B, AUC 0.553) achieves the lowest (22.60), despite being mid-size.
The utility selector's out-of-fold AUC varies 0.55–0.87 across backbones,
while the positive rate of the judge's ratings varies 17%–56%; Qwen2.5-VL-7B
sits at the extreme of both (56% judge-correct hypotheses, selector AUC 0.553).
This reflects a judge-label distribution that is poorly correlated with hypothesis quality in a direction
the profile features cannot capture, and it is the primary cause of that
backbone's lower F1xIoU. The finding suggests that on VideoGlitchBench the
bottleneck is the quality of the judge-derived supervision signal rather than
the VLM's raw capacity, and that improving the calibration target may matter
more than scaling the backbone.


### Refine-mode selection is not backbone-independent

The calibration-selected refine mode differs across backbones: qwen2.5-vl-3b → whole, qwen2.5-vl-7b → window, internvl2.5-4b → window, internvl2.5-8b → frame, ui-tars-1.5-7b → window.
No single mode dominates every backbone, which is consistent with the
expected trade-off: whole-video spans are competitive when per-video
glitch coverage is high, but frame-level bisection wins when the profile
has enough resolution to place boundaries. The differences across modes on
any one backbone are small (see the supplementary per-mode table), so the
choice of refine mode is not the primary driver of the result.

### Baseline choice and SAM3

The GliDe baseline used here is the released code with SAM3 object
tracking enabled where available (Qwen2.5-VL-4B/8B, InternVL2.5-4B/8B,
UI-TARS-1.5-7B), which the GliDe authors report improves their temporal
IoU over the as-released baseline (0.284 → 0.328). For Qwen2.5-VL-3B we
used the released-code baseline (no SAM3). HOVER remains significantly
better than the SAM3-enabled baseline on four of five backbones, which
makes the reported gain a conservative estimate.

## Supplementary material (drop-in)

### Reproducibility

- Framework: HOVER v10.0.
- Preprocessing: GliDe official geometry (fps = 4, window = 8 frames, JPEG
  quality 95, native-resolution stitched grids with per-frame index labels).
- Generation: greedy (temperature 0), top-k disabled explicitly,
  top_logprobs = 20.
- Evaluation judge: meta-llama/Llama-3.1-8B-Instruct, temperature 0.3,
  official GliDe evaluation prompt.
- Statistics: exact game sign-flip permutation test (G = 12 games; min p =
  2^(1-G) = 0.0005); paired game-cluster bootstrap CI (B = 2000); Holm
  correction across the two comparisons per cell.

### Selector diagnostics

| Backbone | Calibration mode | Selected mode | OOF AUC | CI lower | Decision thr. | Degenerate |
|---|---|---|---|---|---|---|
| qwen2.5-vl-3b | whole | whole | 0.867 | 0.824 | 0.1629 | False |
| qwen2.5-vl-7b | window | window | 0.553 | 0.450 | 0.1330 | False |
| internvl2.5-4b | window | window | 0.806 | 0.759 | 0.1354 | False |
| internvl2.5-8b | frame | frame | 0.767 | 0.706 | 0.0801 | False |
| ui-tars-1.5-7b | window | window | 0.764 | 0.718 | 0.1012 | False |

No backbone triggered the degeneracy gate at the default threshold
(min_auc_ci_lo = 0.44). Qwen2.5-VL-7B has the weakest selector (AUC 0.553,
CI lower bound 0.450), which still clears the gate; the other four
backbones have selectors with CI lower bounds at or above 0.70.

### Probe verdicts (go/no-go)

| Backbone | hyp_max within-video AUC | CI | Verdict |
|---|---|---|---|
| qwen2.5-vl-7b | 0.619 | [0.555, 0.683] | GO |

### Honest limitations

1. The utility selector's out-of-fold AUC varies substantially across
   backbones (0.553–0.867). On Qwen2.5-VL-7B it is close to chance, which
   means the selector's threshold is near-uninformative on that backbone;
   its F1xIoU is correspondingly the lowest of the five.
2. Judge ratings are strongly concentrated at 4 on this benchmark (51% of
   ratings), which limits the information content of the 'correct'
   hypothesis label used for calibration.
3. Qwen2.5-VL-3B's comparison against GliDe is against the released-code
   baseline without SAM3; the other four backbones are compared against
   the SAM3-enabled baseline.

### Files

- master_metrics_all.csv — every (backbone, mode, method) with all metrics.
- best_mode_table.csv / .md — main paper table.
- all_mode_comparisons.csv — every HOVER-vs-GliDe comparison, per mode.
- selector_quality.csv — calibration diagnostics.
- mode_aggregate.csv — refine-mode aggregate.

